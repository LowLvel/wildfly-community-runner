# WildFly Community Runner

WildFly integration for IntelliJ IDEA Community/free mode, focused on fast local multi-service development.

## UI in 0.4.3

The WildFly tool window stays intentionally compact: choose a server and service, then use the common actions directly. **Configure…** opens the full manager as a tabbed dialog with **Services**, **Server**, and **Activity** tabs.

Common actions use explicit labels such as **Start Server**, **Debug Server**, **Build + Redeploy**, and **Redeploy Service**. Less frequent utilities are grouped under **More ▾** instead of filling the window with buttons:

- Edit standalone config
- Open WildFly Home
- Open deployments folder
- Open `server.log`

The UI uses the IntelliJ/Swing theme instead of a custom palette. Deployment status uses the IDE's own success/warning/failure colors, so it works naturally in both light and dark themes.

## Highlights

### WildFly server profiles

- Save multiple WildFly installations/versions.
- Select `WILDFLY_HOME` and `standalone*.xml` per profile.
- Optional custom `JAVA_HOME`, startup arguments and WildFly JVM options.
- Configurable debugger port (default `8787`).
- Start Server, Debug Server, Attach Debugger and Stop Server directly from the tool window.
- Common server file/folder shortcuts under **More ▾**.
- Common JVM-option shortcuts with path pickers, including `-Doracle.net.tns_admin=...`, trustStore, keyStore and temp directory. Custom JVM options remain fully editable.

### Multi-service workspace

Each deployable service has its own persistent profile:

- Maven **or Gradle** build system.
- Project selector plus manual build-file picker (`pom.xml`, `build.gradle`, `build.gradle.kts`).
- Independent tasks/goals, build arguments and build JVM options.
- Artifact type (`auto`, WAR, EAR, JAR), optional artifact override and stable WildFly deployment name.
- Build Service, **Build + Redeploy**, Redeploy Service and Undeploy Service operate only on the selected service.
- Auto-detection searches only that service's output: `target/` for Maven or `build/libs/` for Gradle.
- Open the selected module or reveal its built artifact from **More ▾**.

### Nested projects and hierarchy

**Discover Projects** merges projects IntelliJ already knows about with a bounded recursive filesystem scan under the workspace root. This means nested Maven/Gradle services can be discovered even before IntelliJ imports them as modules.

Output/vendor directories such as `.git`, `.idea`, `.gradle`, `target`, `build`, `out`, `node_modules`, and similar folders are skipped.

The service list preserves hierarchy in its display. For example:

```text
backend › billing › api  —  billing-api
backend › orders › api   —  orders-api
frontend › gateway
```

The build-file path remains the canonical identity, so duplicate names in different subfolders remain distinct.

### Included services and bulk actions

The first service-table column is **Include**. It controls only bulk operations; selecting a row is independent from whether it is included.

**Include ▾** provides:

- Include all
- Include none
- Include only selected
- Invert inclusion

The toolbar shows an `N / M included` counter. The current row selection can be cleared with **Esc** or by clicking below the table rows, and an empty selection remains empty across refreshes.

**Bulk Actions ▾** provides:

- Build + redeploy included
- Redeploy included
- Undeploy included
- Undeploy all configured services

Newly discovered services are excluded from bulk operations by default to avoid accidental mass redeploys.

### Deployment status

Statuses are visible at a glance and use IntelliJ theme-aware colors:

- **Deployed** — success color
- **Deploying / Undeploying / Pending** — warning color
- **Failed** — failure color
- **Undeployed / Not deployed / Present** — normal IDE foreground

Periodic status refreshes repaint status only; they do not rebuild the table model or clear the selected service.

## Build engines

### Maven

Maven builds use IntelliJ's bundled Maven runner, so the configured Maven installation/settings in IntelliJ are reused.

### Gradle

Gradle builds prefer the selected project's `gradlew` / `gradlew.bat`, discovered by walking upward from the selected module. If no wrapper exists, the plugin falls back to a system `gradle`/`gradle.bat` command.

Gradle output is streamed into the WildFly Activity panel. Build JVM options are passed to the Gradle build JVM via `-Dorg.gradle.jvmargs=...`.

## Deployment / hot redeploy

Deployments use WildFly's built-in standalone deployment scanner:

1. Build only the selected service.
2. Locate its WAR/EAR/JAR.
3. Copy to a temporary file under `standalone/deployments`.
4. Atomically replace the target when supported.
5. Create `.dodeploy` and watch WildFly's marker files for success/failure.

Other services running in the same WildFly instance are left untouched.

## Debugging

**Debug Server** starts the selected WildFly profile with:

```text
--debug <configured-port>
```

and automatically attaches IntelliJ's Java debugger when the port becomes available. **Attach Debugger** can attach to an already-running WildFly process listening on that port.

Hot redeploy does not require detaching the debugger; the same WildFly JVM remains alive while an individual service is redeployed.

## Threading fixes

The manager preserves service selection during deployment-status refreshes. Maven run-configuration creation is dispatched through IntelliJ's application queue, project-model discovery runs in a read action, and Gradle/process/file work is kept off the UI thread where appropriate. This avoids the selection reset and IDEA 2025.1 write-thread assertion encountered in earlier versions.

## Build the plugin

Requirements:

- JDK 21
- Gradle 9+

```bash
gradle verifyPluginProjectConfiguration
gradle buildPlugin
```

The installable plugin ZIP is generated under:

```text
build/distributions/
```

A GitHub Actions workflow is included and builds/uploads the installable ZIP automatically on pushes to `main`.

## Install

1. Build the plugin (or download the GitHub Actions artifact).
2. IntelliJ IDEA → **Settings → Plugins → gear → Install Plugin from Disk...**
3. Choose the ZIP from `build/distributions/`.
4. Restart IntelliJ.
5. Open **View → Tool Windows → WildFly**.

## Scope

Current scope is local WildFly **standalone mode**. Domain mode and remote deployment-management APIs are intentionally out of scope for this lightweight Community-focused plugin.

## License

Apache-2.0
