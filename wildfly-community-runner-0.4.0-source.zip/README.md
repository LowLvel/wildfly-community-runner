# WildFly Community Runner

WildFly integration for IntelliJ IDEA Community/free mode, focused on fast local multi-service development.

## Highlights

### WildFly server profiles

- Save multiple WildFly installations/versions.
- Select `WILDFLY_HOME` and `standalone*.xml` per profile.
- Optional custom `JAVA_HOME`, startup arguments and WildFly JVM options.
- Configurable debugger port (default `8787`).
- Start, Debug, Attach Debugger and Terminate directly from the tool window.
- One-click **Edit config**, **Open home**, **Deployments**, and **server.log**.
- Common JVM-option shortcuts with path pickers, including `-Doracle.net.tns_admin=...`, trustStore, keyStore and temp directory. Custom JVM options remain fully editable.

### Multi-service workspace

Each deployable service has its own persistent profile:

- Maven **or Gradle** build system.
- Imported-project selector plus manual build-file picker (`pom.xml`, `build.gradle`, `build.gradle.kts`).
- Independent tasks/goals, build arguments and build JVM options.
- Artifact type (`auto`, WAR, EAR, JAR), optional artifact override and stable WildFly deployment name.
- Build, **Build & Hot Redeploy**, Redeploy and Undeploy operate only on the selected service.
- Auto-detection searches only that service's output: `target/` for Maven or `build/libs/` for Gradle.
- Open the selected module or reveal its built artifact with one click.

### Tracked services

The service list has a **Track** checkbox. Bulk actions touch only checked services:

- **Build & Redeploy tracked**
- **Redeploy tracked**
- **All / None / Only / Invert** shortcuts make inclusion/exclusion fast.
- Newly discovered projects are deliberately *not* tracked until you opt in, preventing accidental redeploys.

You can keep many services/modules open in one IntelliJ window while rebuilding and redeploying only the subset you care about.

## Build engines

### Maven

Maven builds use IntelliJ's bundled Maven runner, so the configured Maven installation/settings in IntelliJ are reused.

### Gradle

Gradle builds prefer the project's `gradlew` / `gradlew.bat`, discovered by walking upward from the selected module. If no wrapper exists, the plugin falls back to a system `gradle`/`gradle.bat` command.

Gradle output is streamed into the WildFly Activity panel. Build JVM options are passed to the Gradle build JVM via `-Dorg.gradle.jvmargs=...`.

## Deployment / hot redeploy

Deployments use WildFly's built-in standalone deployment scanner:

1. Build only the selected service.
2. Locate its WAR/EAR/JAR.
3. Copy to a temporary file under `standalone/deployments`.
4. Atomically replace the target when supported.
5. Create `.dodeploy` and watch WildFly's marker files for success/failure.

Other services running in the same WildFly instance are left untouched.

## Debugging

**Debug** starts the selected WildFly profile with:

```text
--debug <configured-port>
```

and automatically attaches IntelliJ's Java debugger when the port becomes available. **Attach Debugger** can attach to an already-running WildFly process listening on that port.

Hot redeploy does not require detaching the debugger; the same WildFly JVM remains alive while an individual service is redeployed.

## Build the plugin

Requirements:

- JDK 21
- Gradle 9+

```bash
gradle verifyPluginProjectConfiguration
gradle buildPlugin
```

The installable plugin ZIP is generated under:

```text
build/distributions/
```

A GitHub Actions workflow is included and builds/uploads the installable ZIP automatically on pushes to `main`.

## Install

1. Build the plugin (or download the GitHub Actions artifact).
2. IntelliJ IDEA → **Settings → Plugins → gear → Install Plugin from Disk...**
3. Choose the ZIP from `build/distributions/`.
4. Restart IntelliJ.
5. Open **View → Tool Windows → WildFly**.

## Scope

Current scope is local WildFly **standalone mode**. Domain mode and remote deployment-management APIs are intentionally out of scope for this lightweight Community-focused plugin.

## License

Apache-2.0
