package io.github.wildflycommunityrunner.ui;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import io.github.wildflycommunityrunner.model.BuildSystem;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.model.ServiceProfile;
import io.github.wildflycommunityrunner.services.BuildProjectDiscoveryService;
import io.github.wildflycommunityrunner.services.BuildProjectDiscoveryService.BuildProjectChoice;
import io.github.wildflycommunityrunner.services.BuildService;
import io.github.wildflycommunityrunner.services.DebugAttachService;
import io.github.wildflycommunityrunner.services.DeploymentScannerService;
import io.github.wildflycommunityrunner.services.WildFlyProcessService;
import io.github.wildflycommunityrunner.settings.WildFlyApplicationSettings;
import io.github.wildflycommunityrunner.settings.WildFlyProjectSettings;
import io.github.wildflycommunityrunner.util.ArtifactLocator;
import io.github.wildflycommunityrunner.util.WildFlyPaths;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

@SuppressWarnings("serial")
public final class WildFlyToolWindowPanel extends JPanel {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final Project project;
    private final JComboBox<ServerProfile> serverCombo = new JComboBox<>();
    private final JLabel serverStateLabel = new JLabel(" ");

    private final ServiceTableModel serviceTableModel = new ServiceTableModel();
    private final JTable serviceTable = new JTable(serviceTableModel);

    private final JComboBox<BuildSystem> buildSystemCombo = new JComboBox<>(BuildSystem.values());
    private final JComboBox<BuildProjectChoice> buildProjectCombo = new JComboBox<>();
    private final JTextField buildFileField = new JTextField();
    private final JTextField serviceNameField = new JTextField();
    private final JComboBox<String> packagingCombo = new JComboBox<>(new String[]{"auto", "war", "ear", "jar"});
    private final JTextField deploymentNameField = new JTextField();
    private final JTextField artifactField = new JTextField();
    private final JTextField tasksField = new JTextField();
    private final JTextField argumentsField = new JTextField();
    private final JTextField buildJvmOptionsField = new JTextField();
    private final JCheckBox deployAfterBuild = new JCheckBox("Deploy after successful build");

    private final JTextArea output = new JTextArea();
    private List<BuildProjectChoice> buildChoices = List.of();
    private boolean loading;
    private boolean loadingService;

    public WildFlyToolWindowPanel(Project project) {
        super(new BorderLayout(8, 8));
        this.project = project;
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        buildUi();
        loadSettings();
        new Timer(2000, e -> {
            if (project.isDisposed()) {
                ((Timer) e.getSource()).stop();
            } else {
                serviceTableModel.fireTableDataChanged();
                refreshServerState();
            }
        }).start();
    }

    private void buildUi() {
        add(buildServerPanel(), BorderLayout.NORTH);

        JSplitPane serviceSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, buildServiceListPanel(), buildServiceEditorPanel());
        serviceSplit.setResizeWeight(0.34);
        serviceSplit.setDividerLocation(330);
        serviceSplit.setBorder(null);

        JPanel outputPanel = new JPanel(new BorderLayout(4, 4));
        JPanel outputHeader = new JPanel(new BorderLayout());
        outputHeader.add(new JLabel("Activity"), BorderLayout.WEST);
        JPanel outputButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 3, 0));
        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> output.setText(""));
        outputButtons.add(clear);
        outputHeader.add(outputButtons, BorderLayout.EAST);
        outputPanel.add(outputHeader, BorderLayout.NORTH);
        output.setEditable(false);
        output.setLineWrap(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, output.getFont().getSize()));
        outputPanel.add(new JScrollPane(output), BorderLayout.CENTER);

        JSplitPane vertical = new JSplitPane(JSplitPane.VERTICAL_SPLIT, serviceSplit, outputPanel);
        vertical.setResizeWeight(0.70);
        vertical.setDividerLocation(465);
        vertical.setBorder(null);
        add(vertical, BorderLayout.CENTER);
    }

    private JComponent buildServerPanel() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createTitledBorder("WildFly server"));

        JPanel row = new JPanel(new BorderLayout(6, 0));
        row.add(serverCombo, BorderLayout.CENTER);
        JPanel profileButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        serverStateLabel.setToolTipText("State of the WildFly process started by this plugin");
        JButton add = new JButton("+"); add.setToolTipText("Add server profile");
        JButton edit = new JButton("Server…");
        JButton remove = new JButton("−"); remove.setToolTipText("Remove server profile");
        profileButtons.add(serverStateLabel); profileButtons.add(add); profileButtons.add(edit); profileButtons.add(remove);
        row.add(profileButtons, BorderLayout.EAST);
        card.add(row);
        card.add(Box.createVerticalStrut(5));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        JButton start = new JButton("Start");
        JButton debug = new JButton("Debug");
        JButton attach = new JButton("Attach Debugger");
        JButton stop = new JButton("Terminate");
        JButton config = new JButton("Edit config");
        JButton home = new JButton("Open home");
        JButton deployments = new JButton("Deployments");
        JButton log = new JButton("server.log");
        actions.add(start); actions.add(debug); actions.add(attach); actions.add(stop);
        actions.add(Box.createHorizontalStrut(8));
        actions.add(config); actions.add(home); actions.add(deployments); actions.add(log);
        card.add(actions);

        add.addActionListener(e -> addServer());
        edit.addActionListener(e -> editServer());
        remove.addActionListener(e -> removeServer());
        serverCombo.addActionListener(e -> { saveSelectedServer(); serviceTableModel.fireTableDataChanged(); refreshServerState(); });
        start.addActionListener(e -> startServer(false));
        debug.addActionListener(e -> startDebug());
        attach.addActionListener(e -> attachDebugger());
        stop.addActionListener(e -> terminateServer());
        config.addActionListener(e -> editStandaloneConfig());
        home.addActionListener(e -> openWildFlyHome());
        deployments.addActionListener(e -> openDeploymentsFolder());
        log.addActionListener(e -> openLog());
        return card;
    }

    private JComponent buildServiceListPanel() {
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createTitledBorder("Services"));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
        JButton discover = new JButton("Sync projects");
        discover.setToolTipText("Discover imported Maven projects and Gradle modules without auto-tracking them");
        JButton addCustom = new JButton("+"); addCustom.setToolTipText("Add custom service profile");
        JButton remove = new JButton("−"); remove.setToolTipText("Remove selected service profile");
        JButton all = new JButton("All");
        JButton none = new JButton("None");
        JButton only = new JButton("Only"); only.setToolTipText("Track only the selected service");
        JButton invert = new JButton("Invert");
        toolbar.add(discover); toolbar.add(addCustom); toolbar.add(remove);
        toolbar.add(Box.createHorizontalStrut(6)); toolbar.add(all); toolbar.add(none); toolbar.add(only); toolbar.add(invert);
        panel.add(toolbar, BorderLayout.NORTH);

        serviceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        serviceTable.setFillsViewportHeight(true);
        serviceTable.getColumnModel().getColumn(0).setMaxWidth(48);
        serviceTable.getColumnModel().getColumn(2).setPreferredWidth(65);
        serviceTable.getColumnModel().getColumn(3).setPreferredWidth(95);
        serviceTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadSelectedService();
        });
        panel.add(new JScrollPane(serviceTable), BorderLayout.CENTER);

        JPanel bulk = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        JButton rebuildTracked = new JButton("Build & Redeploy tracked");
        rebuildTracked.setToolTipText("Sequentially rebuilds and hot-redeploys only checked services");
        JButton redeployTracked = new JButton("Redeploy tracked");
        bulk.add(rebuildTracked); bulk.add(redeployTracked);
        panel.add(bulk, BorderLayout.SOUTH);

        discover.addActionListener(e -> discoverBuildProjects());
        addCustom.addActionListener(e -> addCustomService());
        remove.addActionListener(e -> removeSelectedService());
        all.addActionListener(e -> setTrackedMode(1));
        none.addActionListener(e -> setTrackedMode(0));
        only.addActionListener(e -> trackOnlySelected());
        invert.addActionListener(e -> setTrackedMode(-1));
        rebuildTracked.addActionListener(e -> buildTrackedServices());
        redeployTracked.addActionListener(e -> redeployTrackedServices());
        return panel;
    }

    private JComponent buildServiceEditorPanel() {
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createTitledBorder("Selected service"));
        JPanel fields = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(3, 3, 3, 3);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridy = 0;

        addRow(fields, c, "Service name", serviceNameField, null);
        addRow(fields, c, "Build system", buildSystemCombo, null);
        JButton refreshProjects = new JButton("↻"); refreshProjects.setToolTipText("Refresh Maven/Gradle projects");
        addRow(fields, c, "Imported project", buildProjectCombo, refreshProjects);
        JButton browseBuildFile = new JButton("Browse…");
        addRow(fields, c, "Build file", buildFileField, browseBuildFile);
        addRow(fields, c, "Artifact type", packagingCombo, null);
        addRow(fields, c, "Deployment name", deploymentNameField, null);
        JButton browseArtifact = new JButton("Browse…");
        addRow(fields, c, "Artifact override", artifactField, browseArtifact);
        addRow(fields, c, "Tasks / goals", tasksField, null);
        addRow(fields, c, "Build arguments", argumentsField, null);
        addRow(fields, c, "Quick JVM option", new JvmOptionShortcutPanel(buildJvmOptionsField), null);
        addRow(fields, c, "Build JVM options", buildJvmOptionsField, null);
        c.gridx = 1; c.weightx = 1; c.gridwidth = 2;
        fields.add(deployAfterBuild, c); c.gridy++;

        JLabel hint = new JLabel("Blank Artifact = auto-detect target/ (Maven) or build/libs/ (Gradle). Deployment name stays stable across versions.");
        c.gridx = 1; c.gridwidth = 2;
        fields.add(hint, c);
        panel.add(fields, BorderLayout.NORTH);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        JButton build = new JButton("Build");
        JButton buildDeploy = new JButton("Build & Hot Redeploy");
        JButton redeploy = new JButton("Redeploy artifact");
        JButton undeploy = new JButton("Undeploy");
        JButton openModule = new JButton("Open module");
        JButton openArtifact = new JButton("Show artifact");
        actions.add(build); actions.add(buildDeploy); actions.add(redeploy); actions.add(undeploy);
        actions.add(Box.createHorizontalStrut(6)); actions.add(openModule); actions.add(openArtifact);
        panel.add(actions, BorderLayout.SOUTH);

        buildSystemCombo.addActionListener(e -> buildSystemChanged());
        refreshProjects.addActionListener(e -> refreshBuildChoices());
        buildProjectCombo.addActionListener(e -> applyBuildChoice());
        browseBuildFile.addActionListener(e -> browseBuildFile());
        browseArtifact.addActionListener(e -> browseArtifact());
        packagingCombo.addActionListener(e -> saveSelectedServiceFields());
        build.addActionListener(e -> buildSelected(false));
        buildDeploy.addActionListener(e -> buildSelected(true));
        redeploy.addActionListener(e -> deploySelected(null));
        undeploy.addActionListener(e -> undeploySelected(null));
        openModule.addActionListener(e -> openSelectedModuleFolder());
        openArtifact.addActionListener(e -> openSelectedArtifactFolder());

        DocumentListener saver = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { saveSelectedServiceFields(); }
            @Override public void removeUpdate(DocumentEvent e) { saveSelectedServiceFields(); }
            @Override public void changedUpdate(DocumentEvent e) { saveSelectedServiceFields(); }
        };
        serviceNameField.getDocument().addDocumentListener(saver);
        buildFileField.getDocument().addDocumentListener(saver);
        deploymentNameField.getDocument().addDocumentListener(saver);
        artifactField.getDocument().addDocumentListener(saver);
        tasksField.getDocument().addDocumentListener(saver);
        argumentsField.getDocument().addDocumentListener(saver);
        buildJvmOptionsField.getDocument().addDocumentListener(saver);
        deployAfterBuild.addActionListener(e -> saveSelectedServiceFields());
        return panel;
    }

    private static void addRow(JPanel panel, GridBagConstraints c, String label, JComponent field, JComponent extra) {
        c.gridwidth = 1; c.gridx = 0; c.weightx = 0;
        panel.add(new JLabel(label + ":"), c);
        c.gridx = 1; c.weightx = 1;
        panel.add(field, c);
        if (extra != null) {
            c.gridx = 2; c.weightx = 0;
            panel.add(extra, c);
        }
        c.gridy++;
    }

    private void loadSettings() {
        loading = true;
        refreshServers();
        refreshBuildChoices();
        WildFlyProjectSettings.StateData state = WildFlyProjectSettings.getInstance(project).getState();
        selectServerById(state.selectedServerId);
        migrateOldSettingsIfNeeded(state);
        for (ServiceProfile service : state.services) service.migrateLegacyFields();
        serviceTableModel.fireTableDataChanged();
        selectServiceById(state.selectedServiceId);
        if (serviceTable.getSelectedRow() < 0 && serviceTableModel.getRowCount() > 0) serviceTable.setRowSelectionInterval(0, 0);
        loading = false;
        loadSelectedService();
        refreshServerState();
    }

    private void migrateOldSettingsIfNeeded(WildFlyProjectSettings.StateData state) {
        if (!state.services.isEmpty()) return;
        if ((state.mavenWorkingDirectory == null || state.mavenWorkingDirectory.isBlank())
                && (state.artifactPath == null || state.artifactPath.isBlank())) return;
        ServiceProfile legacy = new ServiceProfile();
        legacy.name = "Legacy service";
        legacy.buildSystem = BuildSystem.MAVEN.name();
        if (state.mavenWorkingDirectory != null && !state.mavenWorkingDirectory.isBlank()) {
            legacy.buildFilePath = Path.of(state.mavenWorkingDirectory).resolve("pom.xml").toString();
        }
        legacy.artifactPath = state.artifactPath == null ? "" : state.artifactPath;
        legacy.buildTasks = state.mavenGoals == null || state.mavenGoals.isBlank() ? "clean package" : state.mavenGoals;
        state.services.add(legacy);
    }

    private void refreshServers() {
        String selectedId = selectedServer() == null ? null : selectedServer().id;
        DefaultComboBoxModel<ServerProfile> model = new DefaultComboBoxModel<>();
        for (ServerProfile server : WildFlyApplicationSettings.getInstance().servers()) model.addElement(server);
        serverCombo.setModel(model);
        selectServerById(selectedId);
    }

    private void refreshBuildChoices() {
        String selectedPath = selectedService() == null ? null : selectedService().buildFilePath;
        buildChoices = BuildProjectDiscoveryService.discover(project);
        refreshBuildProjectCombo(selectedPath);
    }

    private void refreshBuildProjectCombo(String selectedPath) {
        BuildSystem wantedSystem = (BuildSystem) buildSystemCombo.getSelectedItem();
        if (wantedSystem == null && selectedService() != null) wantedSystem = selectedService().buildSystemEnum();
        DefaultComboBoxModel<BuildProjectChoice> model = new DefaultComboBoxModel<>();
        for (BuildProjectChoice choice : buildChoices) {
            if (wantedSystem == null || choice.system() == wantedSystem) model.addElement(choice);
        }
        model.setSelectedItem(null);
        buildProjectCombo.setModel(model);
        if (selectedPath != null) selectBuildChoice(selectedPath);
    }

    private void discoverBuildProjects() {
        refreshBuildChoices();
        WildFlyProjectSettings.StateData state = projectState();
        int added = 0;
        for (BuildProjectChoice choice : buildChoices) {
            if (state.services.stream().anyMatch(s -> samePath(s.buildFilePath, choice.buildFilePath()))) continue;
            ServiceProfile s = new ServiceProfile();
            s.name = choice.name();
            s.buildSystem = choice.system().name();
            s.buildFilePath = choice.buildFilePath();
            s.packaging = normalizePackaging(choice.packaging());
            s.buildTasks = s.defaultTasks();
            s.buildArguments = choice.system() == BuildSystem.MAVEN ? "-DskipTests" : "-x test";
            s.tracked = false;
            s.deploymentName = defaultDeploymentName(s);
            state.services.add(s);
            added++;
        }
        serviceTableModel.fireTableDataChanged();
        if (serviceTable.getSelectedRow() < 0 && !state.services.isEmpty()) serviceTable.setRowSelectionInterval(0, 0);
        append(added == 0 ? "Build projects are already in sync." : "Discovered " + added + " Maven/Gradle service(s). Check Track for bulk operations.");
    }

    private void addCustomService() {
        ServiceProfile s = new ServiceProfile();
        s.name = "Custom service";
        s.tracked = false;
        projectState().services.add(s);
        int row = projectState().services.size() - 1;
        serviceTableModel.fireTableRowsInserted(row, row);
        serviceTable.setRowSelectionInterval(row, row);
    }

    private void removeSelectedService() {
        int row = serviceTable.getSelectedRow();
        if (row < 0) return;
        ServiceProfile service = projectState().services.get(row);
        int answer = JOptionPane.showConfirmDialog(this, "Remove service profile '" + service.name + "'?",
                "Remove Service", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) return;
        projectState().services.remove(row);
        serviceTableModel.fireTableDataChanged();
        if (!projectState().services.isEmpty()) {
            int next = Math.min(row, projectState().services.size() - 1);
            serviceTable.setRowSelectionInterval(next, next);
        } else {
            loadSelectedService();
        }
    }

    private void setTrackedMode(int mode) {
        for (ServiceProfile service : projectState().services) {
            if (mode > 0) service.tracked = true;
            else if (mode == 0) service.tracked = false;
            else service.tracked = !service.tracked;
        }
        serviceTableModel.fireTableDataChanged();
    }

    private void trackOnlySelected() {
        ServiceProfile selected = selectedService();
        if (selected == null) { append("Select a service first."); return; }
        for (ServiceProfile service : projectState().services) service.tracked = service.id.equals(selected.id);
        serviceTableModel.fireTableDataChanged();
    }

    private void loadSelectedService() {
        loadingService = true;
        ServiceProfile s = selectedService();
        boolean enabled = s != null;
        setEditorEnabled(enabled);
        if (s == null) {
            serviceNameField.setText(""); buildFileField.setText(""); deploymentNameField.setText(""); artifactField.setText("");
            tasksField.setText(""); argumentsField.setText(""); buildJvmOptionsField.setText("");
            loadingService = false;
            return;
        }
        s.migrateLegacyFields();
        projectState().selectedServiceId = s.id;
        buildSystemCombo.setSelectedItem(s.buildSystemEnum());
        refreshBuildProjectCombo(s.buildFilePath);
        selectBuildChoice(s.buildFilePath);
        serviceNameField.setText(s.name == null ? "" : s.name);
        buildFileField.setText(s.buildFilePath == null ? "" : s.buildFilePath);
        packagingCombo.setSelectedItem(normalizePackaging(s.packaging));
        deploymentNameField.setText(s.deploymentName == null ? "" : s.deploymentName);
        artifactField.setText(s.artifactPath == null ? "" : s.artifactPath);
        tasksField.setText(s.buildTasks == null || s.buildTasks.isBlank() ? s.defaultTasks() : s.buildTasks);
        argumentsField.setText(s.buildArguments == null ? "" : s.buildArguments);
        buildJvmOptionsField.setText(s.buildJvmOptions == null ? "" : s.buildJvmOptions);
        deployAfterBuild.setSelected(s.deployAfterBuild);
        loadingService = false;
    }

    private void setEditorEnabled(boolean enabled) {
        buildSystemCombo.setEnabled(enabled);
        buildProjectCombo.setEnabled(enabled);
        buildFileField.setEnabled(enabled);
        serviceNameField.setEnabled(enabled);
        packagingCombo.setEnabled(enabled);
        deploymentNameField.setEnabled(enabled);
        artifactField.setEnabled(enabled);
        tasksField.setEnabled(enabled);
        argumentsField.setEnabled(enabled);
        buildJvmOptionsField.setEnabled(enabled);
        deployAfterBuild.setEnabled(enabled);
    }

    private void saveSelectedServiceFields() {
        if (loading || loadingService) return;
        ServiceProfile s = selectedService();
        if (s == null) return;
        BuildSystem system = (BuildSystem) buildSystemCombo.getSelectedItem();
        if (system != null) s.buildSystem = system.name();
        s.name = serviceNameField.getText().trim();
        s.buildFilePath = buildFileField.getText().trim();
        s.packaging = Objects.toString(packagingCombo.getSelectedItem(), "auto");
        s.deploymentName = deploymentNameField.getText().trim();
        s.artifactPath = artifactField.getText().trim();
        s.buildTasks = tasksField.getText().trim();
        s.buildArguments = argumentsField.getText().trim();
        s.buildJvmOptions = buildJvmOptionsField.getText().trim();
        s.deployAfterBuild = deployAfterBuild.isSelected();
        int row = serviceTable.getSelectedRow();
        if (row >= 0) serviceTableModel.fireTableRowsUpdated(row, row);
    }

    private void buildSystemChanged() {
        if (loading || loadingService) return;
        ServiceProfile s = selectedService();
        BuildSystem selected = (BuildSystem) buildSystemCombo.getSelectedItem();
        if (s == null || selected == null) return;
        BuildSystem old = s.buildSystemEnum();
        String oldDefault = old == BuildSystem.GRADLE ? "clean build" : "clean package";
        String oldArgsDefault = old == BuildSystem.GRADLE ? "-x test" : "-DskipTests";
        s.buildSystem = selected.name();
        if (tasksField.getText().isBlank() || tasksField.getText().trim().equals(oldDefault)) {
            tasksField.setText(s.defaultTasks());
        }
        if (argumentsField.getText().isBlank() || argumentsField.getText().trim().equals(oldArgsDefault)) {
            argumentsField.setText(selected == BuildSystem.GRADLE ? "-x test" : "-DskipTests");
        }
        refreshBuildProjectCombo(s.buildFilePath);
        saveSelectedServiceFields();
    }

    private void applyBuildChoice() {
        if (loading || loadingService) return;
        ServiceProfile s = selectedService();
        BuildProjectChoice choice = (BuildProjectChoice) buildProjectCombo.getSelectedItem();
        if (s == null || choice == null) return;
        loadingService = true;
        s.buildSystem = choice.system().name();
        s.buildFilePath = choice.buildFilePath();
        s.packaging = normalizePackaging(choice.packaging());
        if (s.name == null || s.name.isBlank() || "Custom service".equals(s.name)) s.name = choice.name();
        if (s.buildTasks == null || s.buildTasks.isBlank()) s.buildTasks = s.defaultTasks();
        if (s.deploymentName == null || s.deploymentName.isBlank()) s.deploymentName = defaultDeploymentName(s);
        buildSystemCombo.setSelectedItem(choice.system());
        buildFileField.setText(s.buildFilePath);
        packagingCombo.setSelectedItem(s.packaging);
        serviceNameField.setText(s.name);
        tasksField.setText(s.buildTasks);
        deploymentNameField.setText(s.deploymentName);
        loadingService = false;
        serviceTableModel.fireTableDataChanged();
    }

    private void browseBuildFile() {
        ServiceProfile service = selectedService(); if (service == null) return;
        File start = buildFileField.getText().isBlank() ? projectBaseFile() : new File(buildFileField.getText());
        JFileChooser chooser = new JFileChooser(start);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setDialogTitle("Select pom.xml, build.gradle, or build.gradle.kts");
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            Path selected = chooser.getSelectedFile().toPath();
            String name = selected.getFileName().toString();
            if ("pom.xml".equalsIgnoreCase(name)) buildSystemCombo.setSelectedItem(BuildSystem.MAVEN);
            else if (name.equals("build.gradle") || name.equals("build.gradle.kts")) buildSystemCombo.setSelectedItem(BuildSystem.GRADLE);
            buildFileField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void addServer() {
        ServerProfileDialog dialog = new ServerProfileDialog(project, null);
        if (!dialog.showAndGet()) return;
        ServerProfile profile = dialog.getProfile();
        WildFlyApplicationSettings.getInstance().servers().add(profile);
        refreshServers(); serverCombo.setSelectedItem(profile);
        append("Added server profile: " + profile.name);
    }

    private void editServer() {
        ServerProfile current = selectedServer();
        if (current == null) { append("Add a WildFly server first."); return; }
        ServerProfileDialog dialog = new ServerProfileDialog(project, current);
        if (!dialog.showAndGet()) return;
        ServerProfile edited = dialog.getProfile();
        List<ServerProfile> servers = WildFlyApplicationSettings.getInstance().servers();
        for (int i = 0; i < servers.size(); i++) if (servers.get(i).id.equals(current.id)) { servers.set(i, edited); break; }
        refreshServers(); selectServerById(edited.id);
        append("Updated server profile: " + edited.name);
    }

    private void removeServer() {
        ServerProfile current = selectedServer(); if (current == null) return;
        int answer = JOptionPane.showConfirmDialog(this, "Remove server profile '" + current.name + "'?", "Remove WildFly Server", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) return;
        WildFlyApplicationSettings.getInstance().servers().removeIf(p -> p.id.equals(current.id));
        refreshServers(); saveSelectedServer();
    }

    private void startServer(boolean debug) {
        ServerProfile profile = requireServer(); if (profile == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try { WildFlyProcessService.getInstance(project).start(profile, debug, this::append); }
            catch (Exception e) { append("ERROR: " + e.getMessage()); }
        });
    }

    private void startDebug() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                WildFlyProcessService process = WildFlyProcessService.getInstance(project);
                if (process.isRunning(profile) && !process.isDebugRunning(profile)) process.terminateAndWait(profile, this::append);
                if (!process.isRunning(profile)) process.start(profile, true, this::append);
                DebugAttachService.attachWhenAvailable(project, "localhost", profile.debugPort, this::append);
            } catch (Exception e) {
                append("ERROR: " + e.getMessage());
            }
        });
    }

    private void attachDebugger() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        DebugAttachService.attachWhenAvailable(project, "localhost", profile.debugPort, this::append);
    }

    private void terminateServer() {
        ServerProfile profile = requireServer(); if (profile != null) WildFlyProcessService.getInstance(project).terminate(profile, this::append);
    }

    private void buildSelected(boolean forceDeploy) {
        ServiceProfile service = requireService();
        ServerProfile server = forceDeploy || (service != null && service.deployAfterBuild) ? requireServer() : selectedServer();
        if (service == null || ((forceDeploy || service.deployAfterBuild) && server == null)) return;
        saveSelectedServiceFields();
        BuildService.build(project, service,
                () -> { if (forceDeploy || service.deployAfterBuild) deployService(service, server, null); },
                null, this::append);
    }

    private void deploySelected(Runnable completion) {
        ServiceProfile service = requireService(); ServerProfile server = requireServer();
        if (service != null && server != null) deployService(service, server, completion);
    }

    private void deployService(ServiceProfile service, ServerProfile server, Runnable completion) {
        try {
            Path artifact = ArtifactLocator.resolve(project, service);
            String name = ArtifactLocator.effectiveDeploymentName(service, artifact);
            if (service.deploymentName == null || service.deploymentName.isBlank()) service.deploymentName = name;
            append("Deploying only " + service.name + " as " + name);
            DeploymentScannerService.deploy(project, server, artifact, name, this::append, ok -> {
                SwingUtilities.invokeLater(serviceTableModel::fireTableDataChanged);
                if (ok && completion != null) completion.run();
            });
        } catch (Exception e) { append("ERROR: " + e.getMessage()); }
    }

    private void undeploySelected(Runnable completion) {
        ServiceProfile service = requireService(); ServerProfile server = requireServer();
        if (service == null || server == null) return;
        String name = deploymentNameForStatus(service);
        DeploymentScannerService.undeploy(project, server, name, this::append, ok -> {
            SwingUtilities.invokeLater(serviceTableModel::fireTableDataChanged);
            if (ok && completion != null) completion.run();
        });
    }

    private void buildTrackedServices() {
        List<ServiceProfile> tracked = projectState().services.stream().filter(s -> s.tracked).map(ServiceProfile::new).toList();
        if (tracked.isEmpty()) { append("No tracked services. Check the Track column first."); return; }
        ServerProfile server = requireServer(); if (server == null) return;
        append("Building and hot-redeploying " + tracked.size() + " tracked service(s) sequentially.");
        buildTrackedAt(tracked, server, 0);
    }

    private void buildTrackedAt(List<ServiceProfile> services, ServerProfile server, int index) {
        if (index >= services.size()) { append("Tracked services completed."); return; }
        ServiceProfile service = services.get(index);
        BuildService.build(project, service,
                () -> deployService(service, server, () -> buildTrackedAt(services, server, index + 1)),
                () -> append("Bulk operation stopped after build failure in " + service.name),
                this::append);
    }

    private void redeployTrackedServices() {
        List<ServiceProfile> tracked = projectState().services.stream().filter(s -> s.tracked).map(ServiceProfile::new).toList();
        if (tracked.isEmpty()) { append("No tracked services. Check the Track column first."); return; }
        ServerProfile server = requireServer(); if (server == null) return;
        redeployTrackedAt(tracked, server, 0);
    }

    private void redeployTrackedAt(List<ServiceProfile> services, ServerProfile server, int index) {
        if (index >= services.size()) { append("Tracked redeploy completed."); return; }
        deployService(services.get(index), server, () -> redeployTrackedAt(services, server, index + 1));
    }

    private void browseArtifact() {
        ServiceProfile service = selectedService(); if (service == null) return;
        File start = projectBaseFile();
        try { start = BuildService.resolveModuleDir(project, service).toFile(); } catch (Exception ignored) {}
        JFileChooser chooser = new JFileChooser(start);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) artifactField.setText(chooser.getSelectedFile().getAbsolutePath());
    }

    private void editStandaloneConfig() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        openInEditor(WildFlyPaths.configurationFile(profile));
    }

    private void openLog() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        Path log = WildFlyPaths.logFile(profile);
        if (!Files.isRegularFile(log)) { append("server.log not found yet: " + log); return; }
        openInEditor(log);
    }

    private void openWildFlyHome() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        openFolder(WildFlyPaths.home(profile));
    }

    private void openDeploymentsFolder() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        openFolder(WildFlyPaths.deploymentsDir(profile));
    }

    private void openSelectedModuleFolder() {
        ServiceProfile service = requireService(); if (service == null) return;
        try { openFolder(BuildService.resolveModuleDir(project, service)); }
        catch (Exception e) { append("ERROR: " + e.getMessage()); }
    }

    private void openSelectedArtifactFolder() {
        ServiceProfile service = requireService(); if (service == null) return;
        try { openFolder(ArtifactLocator.resolve(project, service).getParent()); }
        catch (Exception e) { append("ERROR: " + e.getMessage()); }
    }

    private void openInEditor(Path path) {
        VirtualFile file = LocalFileSystem.getInstance().refreshAndFindFileByNioFile(path);
        if (file == null) { append("File not found: " + path); return; }
        FileEditorManager.getInstance(project).openFile(file, true);
    }

    private void openFolder(Path path) {
        try {
            if (!Files.isDirectory(path)) { append("Folder not found: " + path); return; }
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(path.toFile());
            else append("Desktop folder opening is not supported on this system: " + path);
        } catch (Exception e) { append("ERROR opening folder: " + e.getMessage()); }
    }

    private void refreshServerState() {
        ServerProfile server = selectedServer();
        if (server == null) { serverStateLabel.setText("No server"); return; }
        WildFlyProcessService process = WildFlyProcessService.getInstance(project);
        if (!process.isRunning(server)) serverStateLabel.setText("Stopped / external");
        else if (process.isDebugRunning(server)) serverStateLabel.setText("Debug :" + server.debugPort);
        else serverStateLabel.setText("Running");
    }

    private WildFlyProjectSettings.StateData projectState() { return WildFlyProjectSettings.getInstance(project).getState(); }
    private ServerProfile selectedServer() { return (ServerProfile) serverCombo.getSelectedItem(); }
    private ServiceProfile selectedService() {
        int row = serviceTable.getSelectedRow();
        return row >= 0 && row < projectState().services.size() ? projectState().services.get(row) : null;
    }
    private ServerProfile requireServer() { ServerProfile p = selectedServer(); if (p == null) append("Add/select a WildFly server first."); return p; }
    private ServiceProfile requireService() { ServiceProfile s = selectedService(); if (s == null) append("Select a service first."); return s; }

    private void saveSelectedServer() {
        if (loading) return;
        ServerProfile p = selectedServer(); projectState().selectedServerId = p == null ? "" : p.id;
    }

    private void selectServerById(String id) {
        if (id == null || id.isBlank()) return;
        for (int i = 0; i < serverCombo.getItemCount(); i++) if (id.equals(serverCombo.getItemAt(i).id)) { serverCombo.setSelectedIndex(i); return; }
    }

    private void selectServiceById(String id) {
        if (id == null || id.isBlank()) return;
        for (int i = 0; i < projectState().services.size(); i++) if (id.equals(projectState().services.get(i).id)) { serviceTable.setRowSelectionInterval(i, i); return; }
    }

    private void selectBuildChoice(String buildFilePath) {
        if (buildFilePath == null || buildFilePath.isBlank()) { buildProjectCombo.setSelectedItem(null); return; }
        for (int i = 0; i < buildProjectCombo.getItemCount(); i++) {
            BuildProjectChoice choice = buildProjectCombo.getItemAt(i);
            if (samePath(buildFilePath, choice.buildFilePath())) { buildProjectCombo.setSelectedIndex(i); return; }
        }
        buildProjectCombo.setSelectedItem(null);
    }

    private static boolean samePath(String a, String b) {
        if (a == null || b == null || a.isBlank() || b.isBlank()) return false;
        try { return Path.of(a).toAbsolutePath().normalize().equals(Path.of(b).toAbsolutePath().normalize()); }
        catch (Exception e) { return Objects.equals(a, b); }
    }

    private static String normalizePackaging(String packaging) {
        if (packaging == null) return "auto";
        String value = packaging.trim().toLowerCase(Locale.ROOT);
        return List.of("war", "ear", "jar").contains(value) ? value : "auto";
    }

    private static String defaultDeploymentName(ServiceProfile s) {
        String ext = normalizePackaging(s.packaging);
        if ("auto".equals(ext)) ext = "war";
        String base = s.name == null || s.name.isBlank() ? "service" : s.name.replaceAll("[^A-Za-z0-9._-]", "-");
        return base + "." + ext;
    }

    private String deploymentNameForStatus(ServiceProfile s) {
        return s.deploymentName == null || s.deploymentName.isBlank() ? defaultDeploymentName(s) : s.deploymentName.trim();
    }

    private File projectBaseFile() {
        String base = project.getBasePath();
        return base == null ? null : new File(base);
    }

    private void append(String message) {
        if (message == null || message.isBlank()) return;
        SwingUtilities.invokeLater(() -> {
            output.append("[" + LocalTime.now().format(TIME) + "] " + message + System.lineSeparator());
            output.setCaretPosition(output.getDocument().getLength());
        });
    }

    private final class ServiceTableModel extends AbstractTableModel {
        private final String[] columns = {"Track", "Service", "Build", "Status"};
        @Override public int getRowCount() { return projectState().services.size(); }
        @Override public int getColumnCount() { return columns.length; }
        @Override public String getColumnName(int column) { return columns[column]; }
        @Override public Class<?> getColumnClass(int columnIndex) { return columnIndex == 0 ? Boolean.class : String.class; }
        @Override public boolean isCellEditable(int rowIndex, int columnIndex) { return columnIndex == 0; }
        @Override public Object getValueAt(int rowIndex, int columnIndex) {
            ServiceProfile s = projectState().services.get(rowIndex);
            s.migrateLegacyFields();
            return switch (columnIndex) {
                case 0 -> s.tracked;
                case 1 -> s.name;
                case 2 -> s.buildSystemEnum().toString();
                case 3 -> DeploymentScannerService.status(selectedServer(), deploymentNameForStatus(s));
                default -> "";
            };
        }
        @Override public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
            if (columnIndex == 0 && aValue instanceof Boolean b) {
                projectState().services.get(rowIndex).tracked = b;
                fireTableCellUpdated(rowIndex, columnIndex);
            }
        }
    }
}
