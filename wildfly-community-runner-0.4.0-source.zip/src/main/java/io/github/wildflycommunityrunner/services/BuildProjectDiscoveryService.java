package io.github.wildflycommunityrunner.services;

import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ModuleRootManager;
import com.intellij.openapi.vfs.VirtualFile;
import io.github.wildflycommunityrunner.model.BuildSystem;
import org.jetbrains.idea.maven.project.MavenProject;
import org.jetbrains.idea.maven.project.MavenProjectsManager;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BuildProjectDiscoveryService {
    public record BuildProjectChoice(String name, BuildSystem system, String buildFilePath, String packaging) {
        @Override
        public String toString() {
            return name + "  —  " + system + "  —  " + buildFilePath;
        }
    }

    private BuildProjectDiscoveryService() {}

    public static List<BuildProjectChoice> discover(Project project) {
        Map<String, BuildProjectChoice> byPath = new LinkedHashMap<>();
        discoverMaven(project, byPath);
        discoverGradle(project, byPath);
        return byPath.values().stream()
                .sorted(Comparator.comparing(BuildProjectChoice::name, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    private static void discoverMaven(Project project, Map<String, BuildProjectChoice> out) {
        MavenProjectsManager manager = MavenProjectsManager.getInstance(project);
        if (!manager.isInitialized()) return;
        for (MavenProject mp : manager.getProjects()) {
            String artifactId = mp.getMavenId().getArtifactId();
            String name = artifactId == null || artifactId.isBlank() ? mp.getFile().getNameWithoutExtension() : artifactId;
            String packaging = mp.getPackaging() == null ? "" : mp.getPackaging();
            if ("pom".equalsIgnoreCase(packaging)) continue;
            String path = mp.getFile().getPath();
            out.put(normalized(path), new BuildProjectChoice(name, BuildSystem.MAVEN, path, packaging));
        }
    }

    private static void discoverGradle(Project project, Map<String, BuildProjectChoice> out) {
        List<Path> roots = new ArrayList<>();
        String base = project.getBasePath();
        if (base != null) roots.add(Path.of(base));
        for (Module module : ModuleManager.getInstance(project).getModules()) {
            for (VirtualFile root : ModuleRootManager.getInstance(module).getContentRoots()) {
                try { roots.add(Path.of(root.getPath())); } catch (Exception ignored) {}
            }
        }

        for (Path root : roots) {
            Path file = firstGradleBuildFile(root);
            if (file == null) continue;
            String key = normalized(file.toString());
            if (out.containsKey(key)) continue;
            String name = root.getFileName() == null ? moduleNameFromProject(project) : root.getFileName().toString();
            out.put(key, new BuildProjectChoice(name, BuildSystem.GRADLE, file.toString(), inferGradlePackaging(file)));
        }
    }

    private static Path firstGradleBuildFile(Path root) {
        if (root == null) return null;
        Path kotlin = root.resolve("build.gradle.kts");
        if (Files.isRegularFile(kotlin)) return kotlin;
        Path groovy = root.resolve("build.gradle");
        return Files.isRegularFile(groovy) ? groovy : null;
    }

    private static String inferGradlePackaging(Path buildFile) {
        try {
            String text = Files.readString(buildFile);
            String compact = text.toLowerCase();
            if (compact.contains("ear") && (compact.contains("id(\"ear\")") || compact.contains("plugin: 'ear'") || compact.contains("plugin = 'ear'"))) return "ear";
            if (compact.contains("war") && (compact.contains("id(\"war\")") || compact.contains("plugin: 'war'") || compact.contains("plugin = 'war'"))) return "war";
        } catch (Exception ignored) {}
        return "jar";
    }

    private static String moduleNameFromProject(Project project) {
        String name = project.getName();
        return name == null || name.isBlank() ? "Gradle project" : name;
    }

    private static String normalized(String path) {
        try { return Path.of(path).toAbsolutePath().normalize().toString(); }
        catch (Exception e) { return path; }
    }
}
