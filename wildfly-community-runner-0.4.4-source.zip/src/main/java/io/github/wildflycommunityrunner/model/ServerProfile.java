package io.github.wildflycommunityrunner.model;

import java.util.Objects;
import java.util.UUID;

public class ServerProfile {
    public String id = UUID.randomUUID().toString();
    public String name = "WildFly";
    public String home = "";
    public String configuration = "standalone.xml";
    public String javaHome = "";
    public int debugPort = 8787;
    public String startupArguments = "";
    public String jvmOptions = "";

    public ServerProfile() {}

    public ServerProfile(ServerProfile other) {
        this.id = other.id;
        this.name = other.name;
        this.home = other.home;
        this.configuration = other.configuration;
        this.javaHome = other.javaHome;
        this.debugPort = other.debugPort;
        this.startupArguments = other.startupArguments;
        this.jvmOptions = other.jvmOptions;
    }

    @Override
    public String toString() {
        return name + (home == null || home.isBlank() ? "" : "  —  " + home);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ServerProfile that)) return false;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
