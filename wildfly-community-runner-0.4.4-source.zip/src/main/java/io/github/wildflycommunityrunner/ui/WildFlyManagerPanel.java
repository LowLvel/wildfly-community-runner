package io.github.wildflycommunityrunner.ui;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.ui.JBUI;
import io.github.wildflycommunityrunner.model.BuildSystem;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.model.ServiceProfile;
import io.github.wildflycommunityrunner.services.BuildProjectDiscoveryService;
import io.github.wildflycommunityrunner.services.BuildProjectDiscoveryService.BuildProjectChoice;
import io.github.wildflycommunityrunner.services.BuildService;
import io.github.wildflycommunityrunner.services.DebugAttachService;
import io.github.wildflycommunityrunner.services.DeploymentScannerService;
import io.github.wildflycommunityrunner.services.WildFlyProcessService;
import io.github.wildflycommunityrunner.settings.WildFlyApplicationSettings;
import io.github.wildflycommunityrunner.settings.WildFlyProjectSettings;
import io.github.wildflycommunityrunner.util.ArtifactLocator;
import io.github.wildflycommunityrunner.util.WildFlyPaths;
import io.github.wildflycommunityrunner.util.ServicePresentation;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

@SuppressWarnings("serial")
public final class WildFlyManagerPanel extends JPanel {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final Project project;
    private final JComboBox<ServerProfile> serverCombo = new JComboBox<>();
    private final JLabel serverStateLabel = new JLabel(" ");

    private final ServiceTableModel serviceTableModel = new ServiceTableModel();
    private final JTable serviceTable = new JTable(serviceTableModel);
    private final JLabel includedCountLabel = new JLabel();

    private final JComboBox<BuildSystem> buildSystemCombo = new JComboBox<>(BuildSystem.values());
    private final JComboBox<BuildProjectChoice> buildProjectCombo = new JComboBox<>();
    private final JTextField buildFileField = new JTextField();
    private final JTextField serviceNameField = new JTextField();
    private final JComboBox<String> packagingCombo = new JComboBox<>(new String[]{"auto", "war", "ear", "jar"});
    private final JTextField deploymentNameField = new JTextField();
    private final JTextField artifactField = new JTextField();
    private final JTextField tasksField = new JTextField();
    private final JTextField argumentsField = new JTextField();
    private final JTextField buildJvmOptionsField = new JTextField();
    private final JCheckBox deployAfterBuild = new JCheckBox("Deploy after successful build");

    private final JTextArea output = new JTextArea();
    private final Timer refreshTimer;
    private List<BuildProjectChoice> buildChoices = List.of();
    private boolean loading;
    private boolean loadingService;
    private boolean refreshingTable;

    public WildFlyManagerPanel(Project project) {
        super(new BorderLayout(8, 8));
        this.project = project;
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        buildUi();
        loadSettings();
        refreshTimer = new Timer(2000, e -> {
            if (project.isDisposed()) {
                ((Timer) e.getSource()).stop();
            } else {
                // Repaint dynamic status only. Resetting the table model here used to clear
                // the selected service every two seconds.
                serviceTable.repaint();
                refreshServerState();
            }
        });
        refreshTimer.start();
    }

    @Override
    public void addNotify() {
        super.addNotify();
        if (!project.isDisposed() && !refreshTimer.isRunning()) refreshTimer.start();
    }

    @Override
    public void removeNotify() {
        refreshTimer.stop();
        super.removeNotify();
    }

    private void buildUi() {
        JPanel servicesTab = new JPanel(new BorderLayout(6, 6));
        servicesTab.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        servicesTab.add(buildServerPanel(), BorderLayout.NORTH);
        servicesTab.add(buildServiceListPanel(), BorderLayout.CENTER);
        servicesTab.add(buildSelectedServiceActions(), BorderLayout.SOUTH);

        JPanel logsTab = new JPanel(new BorderLayout(4, 4));
        logsTab.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        JPanel logToolbar = new JPanel(new BorderLayout(4, 0));
        JLabel logTitle = new JLabel("WildFly / build activity");
        JPanel logActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 3, 0));
        JButton clear = new JButton("Clear");
        JButton openServerLog = new JButton("Open server.log");
        clear.addActionListener(e -> output.setText(""));
        openServerLog.addActionListener(e -> openLog());
        logActions.add(openServerLog);
        logActions.add(clear);
        logToolbar.add(logTitle, BorderLayout.WEST);
        logToolbar.add(logActions, BorderLayout.EAST);
        logsTab.add(logToolbar, BorderLayout.NORTH);
        output.setEditable(false);
        output.setLineWrap(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, output.getFont().getSize()));
        logsTab.add(new JScrollPane(output), BorderLayout.CENTER);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Services", servicesTab);
        tabs.addTab("Logs", logsTab);
        add(tabs, BorderLayout.CENTER);
    }

    private JComponent buildServerPanel() {
        JPanel card = new JPanel(new BorderLayout(4, 4));
        card.setBorder(BorderFactory.createEmptyBorder(0, 0, 2, 0));

        JPanel selector = new JPanel(new BorderLayout(5, 0));
        serverCombo.setToolTipText("WildFly server profile");
        selector.add(serverCombo, BorderLayout.CENTER);
        serverStateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        serverStateLabel.setToolTipText("State of the WildFly process started by this plugin");
        selector.add(serverStateLabel, BorderLayout.EAST);
        card.add(selector, BorderLayout.NORTH);

        JPanel actions = new JPanel(new GridLayout(1, 3, 4, 0));
        JButton start = new JButton("Start Server");
        start.setToolTipText("Start the selected WildFly server");
        JButton debug = new JButton("Debug Server");
        debug.setToolTipText("Start WildFly with JDWP enabled and attach IntelliJ's debugger");

        JPopupMenu serverMenu = new JPopupMenu();
        JMenuItem attach = new JMenuItem("Attach Debugger");
        JMenuItem stop = new JMenuItem("Stop Server");
        JMenuItem add = new JMenuItem("Add Server Profile…");
        JMenuItem edit = new JMenuItem("Edit Server Profile…");
        JMenuItem remove = new JMenuItem("Remove Server Profile…");
        JMenuItem config = new JMenuItem("Edit standalone config");
        JMenuItem home = new JMenuItem("Open WildFly Home");
        JMenuItem deployments = new JMenuItem("Open deployments folder");
        JMenuItem log = new JMenuItem("Open server.log");
        serverMenu.add(attach); serverMenu.add(stop);
        serverMenu.addSeparator();
        serverMenu.add(add); serverMenu.add(edit); serverMenu.add(remove);
        serverMenu.addSeparator();
        serverMenu.add(config); serverMenu.add(home); serverMenu.add(deployments); serverMenu.add(log);
        JButton more = popupButton("Server ▾", serverMenu);
        more.setToolTipText("Server profile, debugger, configuration, folders and logs");

        actions.add(start); actions.add(debug); actions.add(more);
        card.add(actions, BorderLayout.SOUTH);

        serverCombo.addActionListener(e -> { saveSelectedServer(); serviceTable.repaint(); refreshServerState(); });
        start.addActionListener(e -> startServer(false));
        debug.addActionListener(e -> startDebug());
        attach.addActionListener(e -> attachDebugger());
        stop.addActionListener(e -> terminateServer());
        add.addActionListener(e -> addServer());
        edit.addActionListener(e -> editServer());
        remove.addActionListener(e -> removeServer());
        config.addActionListener(e -> editStandaloneConfig());
        home.addActionListener(e -> openWildFlyHome());
        deployments.addActionListener(e -> openDeploymentsFolder());
        log.addActionListener(e -> openLog());
        return card;
    }

    private JComponent buildServiceListPanel() {
        JPanel panel = new JPanel(new BorderLayout(4, 4));

        JPanel toolbar = new JPanel();
        toolbar.setLayout(new BoxLayout(toolbar, BoxLayout.Y_AXIS));
        JPanel row1 = new JPanel(new GridLayout(1, 3, 4, 0));
        JButton discover = new JButton("Discover");
        discover.setToolTipText("Find Maven and Gradle projects recursively, including nested projects");
        JButton addCustom = new JButton("+ Service");
        addCustom.setToolTipText("Add a service profile");
        JButton editService = new JButton("Edit…");
        editService.setToolTipText("Edit the selected service (double-click or Enter also works)");
        row1.add(discover); row1.add(addCustom); row1.add(editService);

        JPanel row2 = new JPanel(new GridLayout(1, 2, 4, 0));
        JPopupMenu includeMenu = new JPopupMenu();
        JMenuItem includeAll = new JMenuItem("Include all");
        JMenuItem includeNone = new JMenuItem("Include none");
        JMenuItem includeOnly = new JMenuItem("Include only selected");
        JMenuItem includeInvert = new JMenuItem("Invert inclusion");
        includeMenu.add(includeAll); includeMenu.add(includeNone); includeMenu.add(includeOnly); includeMenu.addSeparator(); includeMenu.add(includeInvert);
        JButton include = popupButton("Include ▾", includeMenu);
        include.setToolTipText("Choose services that participate in bulk actions");

        JPopupMenu bulkMenu = new JPopupMenu();
        JMenuItem buildTracked = new JMenuItem("Build + redeploy included");
        JMenuItem redeployTracked = new JMenuItem("Redeploy included");
        JMenuItem undeployTracked = new JMenuItem("Undeploy included");
        JMenuItem undeployAll = new JMenuItem("Undeploy all configured services");
        bulkMenu.add(buildTracked); bulkMenu.add(redeployTracked); bulkMenu.add(undeployTracked); bulkMenu.addSeparator(); bulkMenu.add(undeployAll);
        JButton bulk = popupButton("Bulk ▾", bulkMenu);
        bulk.setToolTipText("Bulk actions use the Include checkboxes");
        row2.add(include); row2.add(bulk);
        includedCountLabel.setHorizontalAlignment(SwingConstants.LEFT);
        includedCountLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 0, 2));

        toolbar.add(row1);
        toolbar.add(Box.createVerticalStrut(4));
        toolbar.add(row2);
        toolbar.add(includedCountLabel);
        panel.add(toolbar, BorderLayout.NORTH);

        serviceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        serviceTable.setFillsViewportHeight(true);
        serviceTable.setRowHeight(Math.max(serviceTable.getRowHeight(), JBUI.scale(24)));
        serviceTable.getColumnModel().getColumn(0).setMaxWidth(JBUI.scale(58));
        serviceTable.getColumnModel().getColumn(0).setMinWidth(JBUI.scale(50));
        serviceTable.getColumnModel().getColumn(2).setPreferredWidth(JBUI.scale(72));
        serviceTable.getColumnModel().getColumn(2).setMaxWidth(JBUI.scale(95));
        serviceTable.getColumnModel().getColumn(3).setPreferredWidth(JBUI.scale(115));
        serviceTable.getColumnModel().getColumn(3).setCellRenderer(new StatusRenderer());
        serviceTable.getColumnModel().getColumn(1).setCellRenderer(new ServiceNameRenderer());
        serviceTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !refreshingTable) loadSelectedService();
        });
        serviceTable.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { handleServiceMouse(e); }
            @Override public void mouseReleased(MouseEvent e) { handleServiceMouse(e); }
            @Override public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e) && e.getClickCount() == 2 && serviceTable.rowAtPoint(e.getPoint()) >= 0) {
                    openSelectedServiceDetails();
                }
            }
        });
        serviceTable.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "clear-service-selection");
        serviceTable.getActionMap().put("clear-service-selection", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { clearServiceSelection(); }
        });
        serviceTable.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "edit-service");
        serviceTable.getActionMap().put("edit-service", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) { openSelectedServiceDetails(); }
        });
        panel.add(new JScrollPane(serviceTable), BorderLayout.CENTER);

        discover.addActionListener(e -> discoverBuildProjects());
        addCustom.addActionListener(e -> addCustomService());
        editService.addActionListener(e -> openSelectedServiceDetails());
        includeAll.addActionListener(e -> setTrackedMode(1));
        includeNone.addActionListener(e -> setTrackedMode(0));
        includeOnly.addActionListener(e -> trackOnlySelected());
        includeInvert.addActionListener(e -> setTrackedMode(-1));
        buildTracked.addActionListener(e -> buildTrackedServices());
        redeployTracked.addActionListener(e -> redeployTrackedServices());
        undeployTracked.addActionListener(e -> undeployTrackedServices());
        undeployAll.addActionListener(e -> undeployAllServices());
        return panel;
    }

    private JComponent buildSelectedServiceActions() {
        JPanel actions = new JPanel(new GridLayout(1, 3, 4, 0));
        JButton buildDeploy = new JButton("Build + Deploy");
        buildDeploy.setToolTipText("Build and hot-redeploy only the selected service");
        JButton redeploy = new JButton("Redeploy");
        redeploy.setToolTipText("Redeploy the latest artifact for the selected service");

        JPopupMenu moreMenu = new JPopupMenu();
        JMenuItem buildOnly = new JMenuItem("Build only");
        JMenuItem undeploy = new JMenuItem("Undeploy");
        JMenuItem edit = new JMenuItem("Edit Service…");
        JMenuItem openModule = new JMenuItem("Open module folder");
        JMenuItem openArtifact = new JMenuItem("Show built artifact");
        JMenuItem remove = new JMenuItem("Remove service profile…");
        moreMenu.add(buildOnly); moreMenu.add(undeploy);
        moreMenu.addSeparator(); moreMenu.add(edit);
        moreMenu.addSeparator(); moreMenu.add(openModule); moreMenu.add(openArtifact);
        moreMenu.addSeparator(); moreMenu.add(remove);
        JButton more = popupButton("Service ▾", moreMenu);
        more.setToolTipText("More actions for the selected service");

        actions.add(buildDeploy); actions.add(redeploy); actions.add(more);
        buildDeploy.addActionListener(e -> buildSelected(true));
        redeploy.addActionListener(e -> deploySelected(null));
        buildOnly.addActionListener(e -> buildSelected(false));
        undeploy.addActionListener(e -> undeploySelected(null));
        edit.addActionListener(e -> openSelectedServiceDetails());
        openModule.addActionListener(e -> openSelectedModuleFolder());
        openArtifact.addActionListener(e -> openSelectedArtifactFolder());
        remove.addActionListener(e -> removeSelectedService());
        return actions;
    }

    private void handleServiceMouse(MouseEvent e) {
        int row = serviceTable.rowAtPoint(e.getPoint());
        if (row < 0) {
            if (SwingUtilities.isLeftMouseButton(e) && e.getID() == MouseEvent.MOUSE_PRESSED) clearServiceSelection();
            return;
        }
        if (e.isPopupTrigger()) {
            if (serviceTable.getSelectedRow() != row) serviceTable.setRowSelectionInterval(row, row);
            serviceContextMenu().show(serviceTable, e.getX(), e.getY());
        }
    }

    private JPopupMenu serviceContextMenu() {
        ServiceProfile selected = selectedService();
        JPopupMenu menu = new JPopupMenu();
        JMenuItem buildDeploy = new JMenuItem("Build + Redeploy");
        JMenuItem build = new JMenuItem("Build only");
        JMenuItem redeploy = new JMenuItem("Redeploy");
        JMenuItem undeploy = new JMenuItem("Undeploy");
        JMenuItem edit = new JMenuItem("Edit Service…");
        JMenuItem include = new JMenuItem(selected != null && selected.tracked ? "Exclude from bulk actions" : "Include in bulk actions");
        JMenuItem only = new JMenuItem("Include only this service");
        JMenuItem module = new JMenuItem("Open module folder");
        JMenuItem artifact = new JMenuItem("Show built artifact");
        JMenuItem remove = new JMenuItem("Remove service profile…");
        menu.add(buildDeploy); menu.add(build); menu.add(redeploy); menu.add(undeploy);
        menu.addSeparator(); menu.add(edit); menu.add(include); menu.add(only);
        menu.addSeparator(); menu.add(module); menu.add(artifact);
        menu.addSeparator(); menu.add(remove);
        buildDeploy.addActionListener(e -> buildSelected(true));
        build.addActionListener(e -> buildSelected(false));
        redeploy.addActionListener(e -> deploySelected(null));
        undeploy.addActionListener(e -> undeploySelected(null));
        edit.addActionListener(e -> openSelectedServiceDetails());
        include.addActionListener(e -> toggleSelectedIncluded());
        only.addActionListener(e -> trackOnlySelected());
        module.addActionListener(e -> openSelectedModuleFolder());
        artifact.addActionListener(e -> openSelectedArtifactFolder());
        remove.addActionListener(e -> removeSelectedService());
        return menu;
    }

    private void toggleSelectedIncluded() {
        ServiceProfile service = selectedService();
        if (service == null) return;
        service.tracked = !service.tracked;
        refreshServiceTablePreservingSelection();
        refreshIncludedCount();
    }

    private void openSelectedServiceDetails() {
        ServiceProfile current = selectedService();
        if (current == null) { append("Select a service first."); return; }
        if (buildChoices.isEmpty()) refreshBuildChoices(false);
        ServiceProfileDialog dialog = new ServiceProfileDialog(project, current, buildChoices);
        if (!dialog.showAndGet()) return;
        ServiceProfile edited = dialog.getProfile();
        copyService(edited, current);
        projectState().selectedServiceId = current.id;
        refreshServiceTablePreservingSelection();
        refreshIncludedCount();
        loadSelectedService();
        append("Updated service: " + current.name);
    }

    private static void copyService(ServiceProfile source, ServiceProfile target) {
        target.tracked = source.tracked;
        target.name = source.name;
        target.buildSystem = source.buildSystem;
        target.buildFilePath = source.buildFilePath;
        target.buildTasks = source.buildTasks;
        target.buildArguments = source.buildArguments;
        target.buildJvmOptions = source.buildJvmOptions;
        target.packaging = source.packaging;
        target.artifactPath = source.artifactPath;
        target.deploymentName = source.deploymentName;
        target.deployAfterBuild = source.deployAfterBuild;
    }

    private JComponent buildServiceEditorPanel() {
        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createTitledBorder("Selected service"));
        JPanel fields = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(3, 3, 3, 3);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridy = 0;

        addRow(fields, c, "Service name", serviceNameField, null);
        addRow(fields, c, "Build system", buildSystemCombo, null);
        JButton refreshProjects = new JButton("↻"); refreshProjects.setToolTipText("Refresh Maven/Gradle projects");
        addRow(fields, c, "Imported project", buildProjectCombo, refreshProjects);
        JButton browseBuildFile = new JButton("Browse…");
        addRow(fields, c, "Build file", buildFileField, browseBuildFile);
        addRow(fields, c, "Artifact type", packagingCombo, null);
        addRow(fields, c, "Deployment name", deploymentNameField, null);
        JButton browseArtifact = new JButton("Browse…");
        addRow(fields, c, "Artifact override", artifactField, browseArtifact);
        addRow(fields, c, "Tasks / goals", tasksField, null);
        addRow(fields, c, "Build arguments", argumentsField, null);
        addRow(fields, c, "Quick JVM option", new JvmOptionShortcutPanel(buildJvmOptionsField), null);
        addRow(fields, c, "Build JVM options", buildJvmOptionsField, null);
        c.gridx = 1; c.weightx = 1; c.gridwidth = 2;
        fields.add(deployAfterBuild, c); c.gridy++;

        JLabel hint = new JLabel("Blank Artifact = auto-detect target/ (Maven) or build/libs/ (Gradle). Deployment name stays stable across versions.");
        c.gridx = 1; c.gridwidth = 2;
        fields.add(hint, c);
        panel.add(fields, BorderLayout.NORTH);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        JButton build = new JButton("Build Service");
        JButton buildDeploy = new JButton("Build + Redeploy");
        JButton redeploy = new JButton("Redeploy Service");
        JButton undeploy = new JButton("Undeploy Service");
        JPopupMenu moreMenu = new JPopupMenu();
        JMenuItem openModule = new JMenuItem("Open module folder");
        JMenuItem openArtifact = new JMenuItem("Show built artifact");
        moreMenu.add(openModule); moreMenu.add(openArtifact);
        JButton more = popupButton("More ▾", moreMenu);
        actions.add(build); actions.add(buildDeploy); actions.add(redeploy); actions.add(undeploy); actions.add(more);
        panel.add(actions, BorderLayout.SOUTH);

        buildSystemCombo.addActionListener(e -> buildSystemChanged());
        refreshProjects.addActionListener(e -> refreshBuildChoicesAsync());
        buildProjectCombo.addActionListener(e -> applyBuildChoice());
        browseBuildFile.addActionListener(e -> browseBuildFile());
        browseArtifact.addActionListener(e -> browseArtifact());
        packagingCombo.addActionListener(e -> saveSelectedServiceFields());
        build.addActionListener(e -> buildSelected(false));
        buildDeploy.addActionListener(e -> buildSelected(true));
        redeploy.addActionListener(e -> deploySelected(null));
        undeploy.addActionListener(e -> undeploySelected(null));
        openModule.addActionListener(e -> openSelectedModuleFolder());
        openArtifact.addActionListener(e -> openSelectedArtifactFolder());

        DocumentListener saver = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { saveSelectedServiceFields(); }
            @Override public void removeUpdate(DocumentEvent e) { saveSelectedServiceFields(); }
            @Override public void changedUpdate(DocumentEvent e) { saveSelectedServiceFields(); }
        };
        serviceNameField.getDocument().addDocumentListener(saver);
        buildFileField.getDocument().addDocumentListener(saver);
        deploymentNameField.getDocument().addDocumentListener(saver);
        artifactField.getDocument().addDocumentListener(saver);
        tasksField.getDocument().addDocumentListener(saver);
        argumentsField.getDocument().addDocumentListener(saver);
        buildJvmOptionsField.getDocument().addDocumentListener(saver);
        deployAfterBuild.addActionListener(e -> saveSelectedServiceFields());
        return panel;
    }

    private static JButton popupButton(String text, JPopupMenu menu) {
        JButton button = new JButton(text);
        button.addActionListener(e -> menu.show(button, 0, button.getHeight()));
        return button;
    }

    private void clearServiceSelection() {
        serviceTable.clearSelection();
        projectState().selectedServiceId = "";
        loadSelectedService();
    }

    private static void addRow(JPanel panel, GridBagConstraints c, String label, JComponent field, JComponent extra) {
        c.gridwidth = 1; c.gridx = 0; c.weightx = 0;
        panel.add(new JLabel(label + ":"), c);
        c.gridx = 1; c.weightx = 1;
        panel.add(field, c);
        if (extra != null) {
            c.gridx = 2; c.weightx = 0;
            panel.add(extra, c);
        }
        c.gridy++;
    }

    private void loadSettings() {
        loading = true;
        refreshServers();
        refreshBuildChoices(false);
        WildFlyProjectSettings.StateData state = WildFlyProjectSettings.getInstance(project).getState();
        selectServerById(state.selectedServerId);
        migrateOldSettingsIfNeeded(state);
        for (ServiceProfile service : state.services) service.migrateLegacyFields();
        serviceTableModel.fireTableDataChanged();
        selectServiceById(state.selectedServiceId);
        loading = false;
        loadSelectedService();
        refreshIncludedCount();
        refreshServerState();
    }

    private void migrateOldSettingsIfNeeded(WildFlyProjectSettings.StateData state) {
        if (!state.services.isEmpty()) return;
        if ((state.mavenWorkingDirectory == null || state.mavenWorkingDirectory.isBlank())
                && (state.artifactPath == null || state.artifactPath.isBlank())) return;
        ServiceProfile legacy = new ServiceProfile();
        legacy.name = "Legacy service";
        legacy.buildSystem = BuildSystem.MAVEN.name();
        if (state.mavenWorkingDirectory != null && !state.mavenWorkingDirectory.isBlank()) {
            legacy.buildFilePath = Path.of(state.mavenWorkingDirectory).resolve("pom.xml").toString();
        }
        legacy.artifactPath = state.artifactPath == null ? "" : state.artifactPath;
        legacy.buildTasks = state.mavenGoals == null || state.mavenGoals.isBlank() ? "clean package" : state.mavenGoals;
        state.services.add(legacy);
    }

    private void refreshServers() {
        String selectedId = selectedServer() == null ? null : selectedServer().id;
        DefaultComboBoxModel<ServerProfile> model = new DefaultComboBoxModel<>();
        for (ServerProfile server : WildFlyApplicationSettings.getInstance().servers()) model.addElement(server);
        serverCombo.setModel(model);
        selectServerById(selectedId);
    }

    private void refreshBuildChoices(boolean recursive) {
        String selectedPath = selectedService() == null ? null : selectedService().buildFilePath;
        buildChoices = recursive
                ? BuildProjectDiscoveryService.discover(project)
                : BuildProjectDiscoveryService.discoverImportedOnly(project);
        refreshBuildProjectCombo(selectedPath);
    }

    private void refreshBuildChoicesAsync() {
        String selectedPath = selectedService() == null ? null : selectedService().buildFilePath;
        append("Discovering Maven/Gradle projects…");
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            List<BuildProjectChoice> discovered = BuildProjectDiscoveryService.discover(project);
            SwingUtilities.invokeLater(() -> {
                buildChoices = discovered;
                refreshBuildProjectCombo(selectedPath);
                append("Project list refreshed: " + discovered.size() + " deployable project(s) found.");
            });
        });
    }

    private void refreshBuildProjectCombo(String selectedPath) {
        BuildSystem wantedSystem = (BuildSystem) buildSystemCombo.getSelectedItem();
        if (wantedSystem == null && selectedService() != null) wantedSystem = selectedService().buildSystemEnum();
        DefaultComboBoxModel<BuildProjectChoice> model = new DefaultComboBoxModel<>();
        for (BuildProjectChoice choice : buildChoices) {
            if (wantedSystem == null || choice.system() == wantedSystem) model.addElement(choice);
        }
        model.setSelectedItem(null);
        buildProjectCombo.setModel(model);
        if (selectedPath != null) selectBuildChoice(selectedPath);
    }

    private void discoverBuildProjects() {
        String selectedPath = selectedService() == null ? null : selectedService().buildFilePath;
        append("Scanning workspace for nested Maven/Gradle projects…");
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            List<BuildProjectChoice> discovered = BuildProjectDiscoveryService.discover(project);
            SwingUtilities.invokeLater(() -> {
                buildChoices = discovered;
                refreshBuildProjectCombo(selectedPath);
                WildFlyProjectSettings.StateData state = projectState();
                int added = 0;
                for (BuildProjectChoice choice : discovered) {
                    if (state.services.stream().anyMatch(s -> samePath(s.buildFilePath, choice.buildFilePath()))) continue;
                    ServiceProfile service = new ServiceProfile();
                    service.name = choice.name();
                    service.buildSystem = choice.system().name();
                    service.buildFilePath = choice.buildFilePath();
                    service.packaging = normalizePackaging(choice.packaging());
                    service.buildTasks = service.defaultTasks();
                    service.buildArguments = choice.system() == BuildSystem.MAVEN ? "-DskipTests" : "-x test";
                    service.tracked = false;
                    service.deploymentName = defaultDeploymentName(service);
                    state.services.add(service);
                    added++;
                }
                refreshServiceTablePreservingSelection();
                refreshIncludedCount();
                append(added == 0
                        ? "Build projects are already in sync."
                        : "Discovered " + added + " Maven/Gradle service(s), including nested projects. Newly discovered services are excluded from bulk actions by default.");
            });
        });
    }

    private void addCustomService() {
        ServiceProfile draft = new ServiceProfile();
        draft.name = "Custom service";
        draft.tracked = false;
        if (buildChoices.isEmpty()) refreshBuildChoices(false);
        ServiceProfileDialog dialog = new ServiceProfileDialog(project, draft, buildChoices);
        if (!dialog.showAndGet()) return;
        ServiceProfile service = dialog.getProfile();
        projectState().services.add(service);
        int row = projectState().services.size() - 1;
        serviceTableModel.fireTableRowsInserted(row, row);
        refreshIncludedCount();
        serviceTable.setRowSelectionInterval(row, row);
        projectState().selectedServiceId = service.id;
        append("Added service: " + service.name);
    }

    private void removeSelectedService() {
        int row = serviceTable.getSelectedRow();
        if (row < 0) return;
        ServiceProfile service = projectState().services.get(row);
        int answer = JOptionPane.showConfirmDialog(this, "Remove service profile '" + service.name + "'?",
                "Remove Service", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) return;
        projectState().services.remove(row);
        serviceTableModel.fireTableDataChanged();
        refreshIncludedCount();
        if (!projectState().services.isEmpty()) {
            int next = Math.min(row, projectState().services.size() - 1);
            serviceTable.setRowSelectionInterval(next, next);
        } else {
            loadSelectedService();
        }
    }

    private void setTrackedMode(int mode) {
        for (ServiceProfile service : projectState().services) {
            if (mode > 0) service.tracked = true;
            else if (mode == 0) service.tracked = false;
            else service.tracked = !service.tracked;
        }
        refreshServiceTablePreservingSelection();
        refreshIncludedCount();
    }

    private void trackOnlySelected() {
        ServiceProfile selected = selectedService();
        if (selected == null) { append("Select a service first."); return; }
        for (ServiceProfile service : projectState().services) service.tracked = service.id.equals(selected.id);
        refreshServiceTablePreservingSelection();
        refreshIncludedCount();
    }

    private void refreshIncludedCount() {
        long included = projectState().services.stream().filter(s -> s.tracked).count();
        includedCountLabel.setText(included + " / " + projectState().services.size() + " included");
        includedCountLabel.setToolTipText("Services included in bulk actions");
    }

    private void refreshServiceTablePreservingSelection() {
        ServiceProfile current = selectedService();
        String selectedId = current != null ? current.id : projectState().selectedServiceId;
        refreshingTable = true;
        try {
            serviceTableModel.fireTableDataChanged();
            if (selectedId != null && !selectedId.isBlank()) selectServiceById(selectedId);
        } finally {
            refreshingTable = false;
        }
    }

    private void loadSelectedService() {
        loadingService = true;
        ServiceProfile s = selectedService();
        boolean enabled = s != null;
        setEditorEnabled(enabled);
        if (s == null) {
            serviceNameField.setText(""); buildFileField.setText(""); deploymentNameField.setText(""); artifactField.setText("");
            tasksField.setText(""); argumentsField.setText(""); buildJvmOptionsField.setText("");
            loadingService = false;
            return;
        }
        s.migrateLegacyFields();
        projectState().selectedServiceId = s.id;
        buildSystemCombo.setSelectedItem(s.buildSystemEnum());
        refreshBuildProjectCombo(s.buildFilePath);
        selectBuildChoice(s.buildFilePath);
        serviceNameField.setText(s.name == null ? "" : s.name);
        buildFileField.setText(s.buildFilePath == null ? "" : s.buildFilePath);
        packagingCombo.setSelectedItem(normalizePackaging(s.packaging));
        deploymentNameField.setText(s.deploymentName == null ? "" : s.deploymentName);
        artifactField.setText(s.artifactPath == null ? "" : s.artifactPath);
        tasksField.setText(s.buildTasks == null || s.buildTasks.isBlank() ? s.defaultTasks() : s.buildTasks);
        argumentsField.setText(s.buildArguments == null ? "" : s.buildArguments);
        buildJvmOptionsField.setText(s.buildJvmOptions == null ? "" : s.buildJvmOptions);
        deployAfterBuild.setSelected(s.deployAfterBuild);
        loadingService = false;
    }

    private void setEditorEnabled(boolean enabled) {
        buildSystemCombo.setEnabled(enabled);
        buildProjectCombo.setEnabled(enabled);
        buildFileField.setEnabled(enabled);
        serviceNameField.setEnabled(enabled);
        packagingCombo.setEnabled(enabled);
        deploymentNameField.setEnabled(enabled);
        artifactField.setEnabled(enabled);
        tasksField.setEnabled(enabled);
        argumentsField.setEnabled(enabled);
        buildJvmOptionsField.setEnabled(enabled);
        deployAfterBuild.setEnabled(enabled);
    }

    private void saveSelectedServiceFields() {
        if (loading || loadingService) return;
        ServiceProfile s = selectedService();
        if (s == null) return;
        BuildSystem system = (BuildSystem) buildSystemCombo.getSelectedItem();
        if (system != null) s.buildSystem = system.name();
        s.name = serviceNameField.getText().trim();
        s.buildFilePath = buildFileField.getText().trim();
        s.packaging = Objects.toString(packagingCombo.getSelectedItem(), "auto");
        s.deploymentName = deploymentNameField.getText().trim();
        s.artifactPath = artifactField.getText().trim();
        s.buildTasks = tasksField.getText().trim();
        s.buildArguments = argumentsField.getText().trim();
        s.buildJvmOptions = buildJvmOptionsField.getText().trim();
        s.deployAfterBuild = deployAfterBuild.isSelected();
        int row = serviceTable.getSelectedRow();
        if (row >= 0) serviceTableModel.fireTableRowsUpdated(row, row);
    }

    private void buildSystemChanged() {
        if (loading || loadingService) return;
        ServiceProfile s = selectedService();
        BuildSystem selected = (BuildSystem) buildSystemCombo.getSelectedItem();
        if (s == null || selected == null) return;
        BuildSystem old = s.buildSystemEnum();
        String oldDefault = old == BuildSystem.GRADLE ? "clean build" : "clean package";
        String oldArgsDefault = old == BuildSystem.GRADLE ? "-x test" : "-DskipTests";
        s.buildSystem = selected.name();
        if (tasksField.getText().isBlank() || tasksField.getText().trim().equals(oldDefault)) {
            tasksField.setText(s.defaultTasks());
        }
        if (argumentsField.getText().isBlank() || argumentsField.getText().trim().equals(oldArgsDefault)) {
            argumentsField.setText(selected == BuildSystem.GRADLE ? "-x test" : "-DskipTests");
        }
        refreshBuildProjectCombo(s.buildFilePath);
        saveSelectedServiceFields();
    }

    private void applyBuildChoice() {
        if (loading || loadingService) return;
        ServiceProfile s = selectedService();
        BuildProjectChoice choice = (BuildProjectChoice) buildProjectCombo.getSelectedItem();
        if (s == null || choice == null) return;
        loadingService = true;
        s.buildSystem = choice.system().name();
        s.buildFilePath = choice.buildFilePath();
        s.packaging = normalizePackaging(choice.packaging());
        if (s.name == null || s.name.isBlank() || "Custom service".equals(s.name)) s.name = choice.name();
        if (s.buildTasks == null || s.buildTasks.isBlank()) s.buildTasks = s.defaultTasks();
        if (s.deploymentName == null || s.deploymentName.isBlank()) s.deploymentName = defaultDeploymentName(s);
        buildSystemCombo.setSelectedItem(choice.system());
        buildFileField.setText(s.buildFilePath);
        packagingCombo.setSelectedItem(s.packaging);
        serviceNameField.setText(s.name);
        tasksField.setText(s.buildTasks);
        deploymentNameField.setText(s.deploymentName);
        loadingService = false;
        refreshServiceTablePreservingSelection();
    }

    private void browseBuildFile() {
        ServiceProfile service = selectedService(); if (service == null) return;
        File start = buildFileField.getText().isBlank() ? projectBaseFile() : new File(buildFileField.getText());
        JFileChooser chooser = new JFileChooser(start);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setDialogTitle("Select pom.xml, build.gradle, or build.gradle.kts");
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            Path selected = chooser.getSelectedFile().toPath();
            String name = selected.getFileName().toString();
            if ("pom.xml".equalsIgnoreCase(name)) buildSystemCombo.setSelectedItem(BuildSystem.MAVEN);
            else if (name.equals("build.gradle") || name.equals("build.gradle.kts")) buildSystemCombo.setSelectedItem(BuildSystem.GRADLE);
            buildFileField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void addServer() {
        ServerProfileDialog dialog = new ServerProfileDialog(project, null);
        if (!dialog.showAndGet()) return;
        ServerProfile profile = dialog.getProfile();
        WildFlyApplicationSettings.getInstance().servers().add(profile);
        refreshServers(); serverCombo.setSelectedItem(profile);
        append("Added server profile: " + profile.name);
    }

    private void editServer() {
        ServerProfile current = selectedServer();
        if (current == null) { append("Add a WildFly server first."); return; }
        ServerProfileDialog dialog = new ServerProfileDialog(project, current);
        if (!dialog.showAndGet()) return;
        ServerProfile edited = dialog.getProfile();
        List<ServerProfile> servers = WildFlyApplicationSettings.getInstance().servers();
        for (int i = 0; i < servers.size(); i++) if (servers.get(i).id.equals(current.id)) { servers.set(i, edited); break; }
        refreshServers(); selectServerById(edited.id);
        append("Updated server profile: " + edited.name);
    }

    private void removeServer() {
        ServerProfile current = selectedServer(); if (current == null) return;
        int answer = JOptionPane.showConfirmDialog(this, "Remove server profile '" + current.name + "'?", "Remove WildFly Server", JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) return;
        WildFlyApplicationSettings.getInstance().servers().removeIf(p -> p.id.equals(current.id));
        refreshServers(); saveSelectedServer();
    }

    private void startServer(boolean debug) {
        ServerProfile profile = requireServer(); if (profile == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try { WildFlyProcessService.getInstance(project).start(profile, debug, this::append); }
            catch (Exception e) { append("ERROR: " + e.getMessage()); }
        });
    }

    private void startDebug() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                WildFlyProcessService process = WildFlyProcessService.getInstance(project);
                if (process.isRunning(profile) && !process.isDebugRunning(profile)) process.terminateAndWait(profile, this::append);
                if (!process.isRunning(profile)) process.start(profile, true, this::append);
                DebugAttachService.attachWhenAvailable(project, "localhost", profile.debugPort, this::append);
            } catch (Exception e) {
                append("ERROR: " + e.getMessage());
            }
        });
    }

    private void attachDebugger() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        DebugAttachService.attachWhenAvailable(project, "localhost", profile.debugPort, this::append);
    }

    private void terminateServer() {
        ServerProfile profile = requireServer(); if (profile != null) WildFlyProcessService.getInstance(project).terminate(profile, this::append);
    }

    private void buildSelected(boolean forceDeploy) {
        ServiceProfile service = requireService();
        ServerProfile server = forceDeploy || (service != null && service.deployAfterBuild) ? requireServer() : selectedServer();
        if (service == null || ((forceDeploy || service.deployAfterBuild) && server == null)) return;
        saveSelectedServiceFields();
        BuildService.build(project, service,
                () -> { if (forceDeploy || service.deployAfterBuild) deployService(service, server, null); },
                null, this::append);
    }

    private void deploySelected(Runnable completion) {
        ServiceProfile service = requireService(); ServerProfile server = requireServer();
        if (service != null && server != null) deployService(service, server, completion);
    }

    private void deployService(ServiceProfile service, ServerProfile server, Runnable completion) {
        try {
            Path artifact = ArtifactLocator.resolve(project, service);
            String name = ArtifactLocator.effectiveDeploymentName(service, artifact);
            if (service.deploymentName == null || service.deploymentName.isBlank()) service.deploymentName = name;
            append("Deploying only " + service.name + " as " + name);
            DeploymentScannerService.deploy(project, server, artifact, name, this::append, ok -> {
                SwingUtilities.invokeLater(serviceTable::repaint);
                if (ok && completion != null) completion.run();
            });
        } catch (Exception e) { append("ERROR: " + e.getMessage()); }
    }

    private void undeploySelected(Runnable completion) {
        ServiceProfile service = requireService(); ServerProfile server = requireServer();
        if (service == null || server == null) return;
        String name = deploymentNameForStatus(service);
        DeploymentScannerService.undeploy(project, server, name, this::append, ok -> {
            SwingUtilities.invokeLater(serviceTable::repaint);
            if (ok && completion != null) completion.run();
        });
    }

    private void buildTrackedServices() {
        List<ServiceProfile> tracked = projectState().services.stream().filter(s -> s.tracked).map(ServiceProfile::new).toList();
        if (tracked.isEmpty()) { append("No included services. Use Include ▾ or check the Include column first."); return; }
        ServerProfile server = requireServer(); if (server == null) return;
        append("Building and hot-redeploying " + tracked.size() + " included service(s) sequentially.");
        buildTrackedAt(tracked, server, 0);
    }

    private void buildTrackedAt(List<ServiceProfile> services, ServerProfile server, int index) {
        if (index >= services.size()) { append("Included services completed."); return; }
        ServiceProfile service = services.get(index);
        BuildService.build(project, service,
                () -> deployService(service, server, () -> buildTrackedAt(services, server, index + 1)),
                () -> append("Bulk operation stopped after build failure in " + service.name),
                this::append);
    }

    private void redeployTrackedServices() {
        List<ServiceProfile> tracked = projectState().services.stream().filter(s -> s.tracked).map(ServiceProfile::new).toList();
        if (tracked.isEmpty()) { append("No included services. Use Include ▾ or check the Include column first."); return; }
        ServerProfile server = requireServer(); if (server == null) return;
        redeployTrackedAt(tracked, server, 0);
    }

    private void redeployTrackedAt(List<ServiceProfile> services, ServerProfile server, int index) {
        if (index >= services.size()) { append("Included redeploy completed."); return; }
        deployService(services.get(index), server, () -> redeployTrackedAt(services, server, index + 1));
    }

    private void undeployTrackedServices() {
        List<ServiceProfile> included = projectState().services.stream().filter(s -> s.tracked).map(ServiceProfile::new).toList();
        if (included.isEmpty()) { append("No included services. Use Include ▾ or check the Include column first."); return; }
        ServerProfile server = requireServer(); if (server == null) return;
        undeployServicesAt(included, server, 0, "Included undeploy completed.");
    }

    private void undeployAllServices() {
        if (projectState().services.isEmpty()) { append("There are no services to undeploy."); return; }
        ServerProfile server = requireServer(); if (server == null) return;
        int answer = JOptionPane.showConfirmDialog(this,
                "Request undeploy for all " + projectState().services.size() + " configured services from '" + server.name + "'?",
                "Undeploy All Services", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (answer != JOptionPane.YES_OPTION) return;
        List<ServiceProfile> all = projectState().services.stream().map(ServiceProfile::new).toList();
        undeployServicesAt(all, server, 0, "All-service undeploy completed.");
    }

    private void undeployServicesAt(List<ServiceProfile> services, ServerProfile server, int index, String completionMessage) {
        if (index >= services.size()) { append(completionMessage); SwingUtilities.invokeLater(serviceTable::repaint); return; }
        ServiceProfile service = services.get(index);
        String name = deploymentNameForStatus(service);
        DeploymentScannerService.undeploy(project, server, name, this::append,
                ok -> undeployServicesAt(services, server, index + 1, completionMessage));
    }

    private void browseArtifact() {
        ServiceProfile service = selectedService(); if (service == null) return;
        File start = projectBaseFile();
        try { start = BuildService.resolveModuleDir(project, service).toFile(); } catch (Exception ignored) {}
        JFileChooser chooser = new JFileChooser(start);
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) artifactField.setText(chooser.getSelectedFile().getAbsolutePath());
    }

    private void editStandaloneConfig() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        openInEditor(WildFlyPaths.configurationFile(profile));
    }

    private void openLog() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        Path log = WildFlyPaths.logFile(profile);
        if (!Files.isRegularFile(log)) { append("server.log not found yet: " + log); return; }
        openInEditor(log);
    }

    private void openWildFlyHome() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        openFolder(WildFlyPaths.home(profile));
    }

    private void openDeploymentsFolder() {
        ServerProfile profile = requireServer(); if (profile == null) return;
        openFolder(WildFlyPaths.deploymentsDir(profile));
    }

    private void openSelectedModuleFolder() {
        ServiceProfile service = requireService(); if (service == null) return;
        try { openFolder(BuildService.resolveModuleDir(project, service)); }
        catch (Exception e) { append("ERROR: " + e.getMessage()); }
    }

    private void openSelectedArtifactFolder() {
        ServiceProfile service = requireService(); if (service == null) return;
        try { openFolder(ArtifactLocator.resolve(project, service).getParent()); }
        catch (Exception e) { append("ERROR: " + e.getMessage()); }
    }

    private void openInEditor(Path path) {
        ApplicationManager.getApplication().invokeLater(() -> {
            VirtualFile file = LocalFileSystem.getInstance().refreshAndFindFileByNioFile(path);
            if (file == null) { append("File not found: " + path); return; }
            FileEditorManager.getInstance(project).openFile(file, true);
        });
    }

    private void openFolder(Path path) {
        try {
            if (!Files.isDirectory(path)) { append("Folder not found: " + path); return; }
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(path.toFile());
            else append("Desktop folder opening is not supported on this system: " + path);
        } catch (Exception e) { append("ERROR opening folder: " + e.getMessage()); }
    }

    private void refreshServerState() {
        ServerProfile server = selectedServer();
        if (server == null) {
            serverStateLabel.setText("No server");
            serverStateLabel.setForeground(UIManager.getColor("Label.foreground"));
            return;
        }
        WildFlyProcessService process = WildFlyProcessService.getInstance(project);
        if (!process.isRunning(server)) {
            serverStateLabel.setText("Stopped / external");
            serverStateLabel.setForeground(UIManager.getColor("Label.foreground"));
        } else if (process.isDebugRunning(server)) {
            serverStateLabel.setText("Debug :" + server.debugPort);
            serverStateLabel.setForeground(JBUI.CurrentTheme.ProgressBar.PASSED);
        } else {
            serverStateLabel.setText("Running");
            serverStateLabel.setForeground(JBUI.CurrentTheme.ProgressBar.PASSED);
        }
    }

    private WildFlyProjectSettings.StateData projectState() { return WildFlyProjectSettings.getInstance(project).getState(); }
    private ServerProfile selectedServer() { return (ServerProfile) serverCombo.getSelectedItem(); }
    private ServiceProfile selectedService() {
        int row = serviceTable.getSelectedRow();
        return row >= 0 && row < projectState().services.size() ? projectState().services.get(row) : null;
    }
    private ServerProfile requireServer() { ServerProfile p = selectedServer(); if (p == null) append("Add/select a WildFly server first."); return p; }
    private ServiceProfile requireService() { ServiceProfile s = selectedService(); if (s == null) append("Select a service first."); return s; }

    private void saveSelectedServer() {
        if (loading) return;
        ServerProfile p = selectedServer(); projectState().selectedServerId = p == null ? "" : p.id;
    }

    private void selectServerById(String id) {
        if (id == null || id.isBlank()) return;
        for (int i = 0; i < serverCombo.getItemCount(); i++) if (id.equals(serverCombo.getItemAt(i).id)) { serverCombo.setSelectedIndex(i); return; }
    }

    private void selectServiceById(String id) {
        if (id == null || id.isBlank()) return;
        for (int i = 0; i < projectState().services.size(); i++) if (id.equals(projectState().services.get(i).id)) { serviceTable.setRowSelectionInterval(i, i); return; }
    }

    private void selectBuildChoice(String buildFilePath) {
        if (buildFilePath == null || buildFilePath.isBlank()) { buildProjectCombo.setSelectedItem(null); return; }
        for (int i = 0; i < buildProjectCombo.getItemCount(); i++) {
            BuildProjectChoice choice = buildProjectCombo.getItemAt(i);
            if (samePath(buildFilePath, choice.buildFilePath())) { buildProjectCombo.setSelectedIndex(i); return; }
        }
        buildProjectCombo.setSelectedItem(null);
    }

    private static boolean samePath(String a, String b) {
        if (a == null || b == null || a.isBlank() || b.isBlank()) return false;
        try { return Path.of(a).toAbsolutePath().normalize().equals(Path.of(b).toAbsolutePath().normalize()); }
        catch (Exception e) { return Objects.equals(a, b); }
    }

    private static String normalizePackaging(String packaging) {
        if (packaging == null) return "auto";
        String value = packaging.trim().toLowerCase(Locale.ROOT);
        return List.of("war", "ear", "jar").contains(value) ? value : "auto";
    }

    private static String defaultDeploymentName(ServiceProfile s) {
        String ext = normalizePackaging(s.packaging);
        if ("auto".equals(ext)) ext = "war";
        String base = s.name == null || s.name.isBlank() ? "service" : s.name.replaceAll("[^A-Za-z0-9._-]", "-");
        return base + "." + ext;
    }

    private String deploymentNameForStatus(ServiceProfile s) {
        return s.deploymentName == null || s.deploymentName.isBlank() ? defaultDeploymentName(s) : s.deploymentName.trim();
    }

    private File projectBaseFile() {
        String base = project.getBasePath();
        return base == null ? null : new File(base);
    }

    private void append(String message) {
        if (message == null || message.isBlank()) return;
        SwingUtilities.invokeLater(() -> {
            output.append("[" + LocalTime.now().format(TIME) + "] " + message + System.lineSeparator());
            output.setCaretPosition(output.getDocument().getLength());
        });
    }

    private final class ServiceTableModel extends AbstractTableModel {
        private final String[] columns = {"Include", "Service / module", "Build", "Status"};
        @Override public int getRowCount() { return projectState().services.size(); }
        @Override public int getColumnCount() { return columns.length; }
        @Override public String getColumnName(int column) { return columns[column]; }
        @Override public Class<?> getColumnClass(int columnIndex) { return columnIndex == 0 ? Boolean.class : String.class; }
        @Override public boolean isCellEditable(int rowIndex, int columnIndex) { return columnIndex == 0; }
        @Override public Object getValueAt(int rowIndex, int columnIndex) {
            ServiceProfile s = projectState().services.get(rowIndex);
            s.migrateLegacyFields();
            return switch (columnIndex) {
                case 0 -> s.tracked;
                case 1 -> ServicePresentation.displayName(project, s);
                case 2 -> s.buildSystemEnum().toString();
                case 3 -> DeploymentScannerService.status(selectedServer(), deploymentNameForStatus(s));
                default -> "";
            };
        }
        @Override public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
            if (columnIndex == 0 && aValue instanceof Boolean b) {
                projectState().services.get(rowIndex).tracked = b;
                fireTableCellUpdated(rowIndex, columnIndex);
                refreshIncludedCount();
            }
        }
    }

    private final class ServiceNameRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            String full = value == null ? "" : value.toString();
            int width = table.getColumnModel().getColumn(column).getWidth() - JBUI.scale(12);
            label.setText(ellipsize(full, label.getFontMetrics(label.getFont()), Math.max(width, JBUI.scale(40))));
            if (row >= 0 && row < projectState().services.size()) {
                ServiceProfile service = projectState().services.get(row);
                String path = ServicePresentation.buildPathTooltip(service);
                label.setToolTipText(path == null || path.isBlank() ? full : full + "\n" + path);
            }
            return label;
        }

        private String ellipsize(String text, FontMetrics metrics, int maxWidth) {
            if (metrics.stringWidth(text) <= maxWidth) return text;
            String suffix = "…";
            int suffixWidth = metrics.stringWidth(suffix);
            int low = 0;
            int high = text.length();
            while (low < high) {
                int mid = (low + high + 1) >>> 1;
                if (metrics.stringWidth(text.substring(0, mid)) + suffixWidth <= maxWidth) low = mid;
                else high = mid - 1;
            }
            return text.substring(0, low) + suffix;
        }
    }

    private static final class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            String status = value == null ? "—" : value.toString();
            label.setText(statusText(status));
            label.setToolTipText(status);
            if (!isSelected) label.setForeground(statusColor(status, table.getForeground()));
            return label;
        }

        private static String statusText(String status) {
            return switch (status) {
                case "DEPLOYED" -> "● Deployed";
                case "FAILED" -> "● Failed";
                case "DEPLOYING" -> "● Deploying";
                case "UNDEPLOYING" -> "● Undeploying";
                case "PENDING" -> "● Pending";
                case "UNDEPLOYED" -> "○ Undeployed";
                case "PRESENT" -> "○ Present";
                case "NOT DEPLOYED" -> "○ Not deployed";
                default -> status;
            };
        }

        private static Color statusColor(String status, Color fallback) {
            return switch (status) {
                case "DEPLOYED" -> JBUI.CurrentTheme.ProgressBar.PASSED;
                case "FAILED" -> JBUI.CurrentTheme.ProgressBar.FAILED;
                case "DEPLOYING", "UNDEPLOYING", "PENDING" -> JBUI.CurrentTheme.ProgressBar.WARNING;
                default -> fallback;
            };
        }
    }
}
