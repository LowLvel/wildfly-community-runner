package io.github.wildflycommunityrunner.ui;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;

public final class WildFlyManagerDialog extends DialogWrapper {
    private final WildFlyManagerPanel panel;

    public WildFlyManagerDialog(Project project) {
        super(project, true);
        setTitle("WildFly Community Runner");
        panel = new WildFlyManagerPanel(project);
        init();
        getOKAction().putValue(Action.NAME, "Close");
    }

    @Override
    protected @Nullable JComponent createCenterPanel() {
        return panel;
    }

    @Override
    protected Action[] createActions() {
        return new Action[]{getOKAction()};
    }
}
