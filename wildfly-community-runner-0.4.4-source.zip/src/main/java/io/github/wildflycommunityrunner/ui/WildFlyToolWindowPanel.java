package io.github.wildflycommunityrunner.ui;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.util.ui.JBUI;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.model.ServiceProfile;
import io.github.wildflycommunityrunner.services.BuildService;
import io.github.wildflycommunityrunner.services.DebugAttachService;
import io.github.wildflycommunityrunner.services.DeploymentScannerService;
import io.github.wildflycommunityrunner.services.WildFlyProcessService;
import io.github.wildflycommunityrunner.settings.WildFlyApplicationSettings;
import io.github.wildflycommunityrunner.settings.WildFlyProjectSettings;
import io.github.wildflycommunityrunner.util.ArtifactLocator;
import io.github.wildflycommunityrunner.util.ServicePresentation;
import io.github.wildflycommunityrunner.util.WildFlyPaths;

import javax.swing.*;
import java.awt.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

@SuppressWarnings("serial")
public final class WildFlyToolWindowPanel extends JPanel {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final Project project;
    private final JComboBox<ServerProfile> serverCombo = new JComboBox<>();
    private final JComboBox<ServiceProfile> serviceCombo = new JComboBox<>();
    private final JLabel serverState = new JLabel(" ");
    private final JLabel deploymentState = new JLabel(" ");
    private final JTextArea activity = new JTextArea(5, 24);
    private final Timer refreshTimer;
    private boolean loading;

    public WildFlyToolWindowPanel(Project project) {
        super(new BorderLayout(8, 8));
        this.project = project;
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        buildUi();
        reloadChoices();
        refreshStatus();
        refreshTimer = new Timer(2000, e -> {
            if (project.isDisposed()) ((Timer) e.getSource()).stop();
            else refreshStatus();
        });
        refreshTimer.start();
    }

    private void buildUi() {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        JPanel heading = new JPanel(new BorderLayout(6, 0));
        JLabel title = new JLabel("WildFly");
        title.setFont(title.getFont().deriveFont(Font.BOLD));
        JButton manager = new JButton("Configure…");
        manager.setToolTipText("Open the full tabbed WildFly manager");
        heading.add(title, BorderLayout.WEST);
        heading.add(manager, BorderLayout.EAST);
        content.add(heading);
        content.add(Box.createVerticalStrut(8));

        serviceCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof ServiceProfile service) {
                    label.setText(ServicePresentation.displayName(project, service));
                    label.setToolTipText(ServicePresentation.buildPathTooltip(service));
                }
                return label;
            }
        });

        content.add(labeledRow("Server", serverCombo, serverState));
        content.add(Box.createVerticalStrut(5));
        content.add(labeledRow("Service", serviceCombo, deploymentState));
        content.add(Box.createVerticalStrut(9));

        JPanel primary = new JPanel(new GridLayout(2, 2, 5, 5));
        JButton start = new JButton("Start Server");
        JButton debug = new JButton("Debug Server");
        JButton buildDeploy = new JButton("Build + Redeploy");
        JButton redeploy = new JButton("Redeploy Service");
        primary.add(start);
        primary.add(debug);
        primary.add(buildDeploy);
        primary.add(redeploy);
        content.add(primary);
        content.add(Box.createVerticalStrut(5));

        JPanel secondary = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        JButton attach = new JButton("Attach Debugger");
        JButton stop = new JButton("Stop Server");
        JButton refresh = new JButton("Refresh");

        JPopupMenu moreMenu = new JPopupMenu();
        JMenuItem undeploy = new JMenuItem("Undeploy selected service");
        JMenuItem config = new JMenuItem("Edit standalone config");
        JMenuItem home = new JMenuItem("Open WildFly Home");
        JMenuItem deployments = new JMenuItem("Open deployments folder");
        JMenuItem log = new JMenuItem("Open server.log");
        moreMenu.add(undeploy);
        moreMenu.addSeparator();
        moreMenu.add(config); moreMenu.add(home); moreMenu.add(deployments); moreMenu.add(log);
        JButton more = popupButton("More ▾", moreMenu);

        secondary.add(attach);
        secondary.add(stop);
        secondary.add(more);
        secondary.add(refresh);
        content.add(secondary);
        content.add(Box.createVerticalStrut(8));

        activity.setEditable(false);
        activity.setLineWrap(true);
        activity.setWrapStyleWord(true);
        activity.setFont(activity.getFont().deriveFont(activity.getFont().getSize2D() - 1f));
        JScrollPane activityScroll = new JScrollPane(activity);
        activityScroll.setBorder(BorderFactory.createTitledBorder("Recent activity"));

        add(content, BorderLayout.NORTH);
        add(activityScroll, BorderLayout.CENTER);

        manager.addActionListener(e -> openManager());
        refresh.addActionListener(e -> reloadChoices());
        serverCombo.addActionListener(e -> {
            if (!loading) {
                ServerProfile server = selectedServer();
                WildFlyProjectSettings.getInstance(project).getState().selectedServerId = server == null ? "" : server.id;
                refreshStatus();
            }
        });
        serviceCombo.addActionListener(e -> {
            if (!loading) {
                ServiceProfile service = selectedService();
                WildFlyProjectSettings.getInstance(project).getState().selectedServiceId = service == null ? "" : service.id;
                refreshStatus();
            }
        });
        start.addActionListener(e -> start(false));
        debug.addActionListener(e -> startDebug());
        attach.addActionListener(e -> attach());
        stop.addActionListener(e -> stop());
        buildDeploy.addActionListener(e -> buildAndRedeploy());
        redeploy.addActionListener(e -> redeploy());
        undeploy.addActionListener(e -> undeploy());
        config.addActionListener(e -> editStandaloneConfig());
        home.addActionListener(e -> openWildFlyHome());
        deployments.addActionListener(e -> openDeploymentsFolder());
        log.addActionListener(e -> openLog());
    }

    private static JButton popupButton(String text, JPopupMenu menu) {
        JButton button = new JButton(text);
        button.addActionListener(e -> menu.show(button, 0, button.getHeight()));
        return button;
    }

    private JPanel labeledRow(String label, JComponent field, JLabel state) {
        JPanel row = new JPanel(new BorderLayout(5, 0));
        JLabel l = new JLabel(label + ":");
        l.setPreferredSize(new Dimension(54, l.getPreferredSize().height));
        row.add(l, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        state.setHorizontalAlignment(SwingConstants.RIGHT);
        state.setPreferredSize(new Dimension(120, state.getPreferredSize().height));
        row.add(state, BorderLayout.EAST);
        return row;
    }

    private void reloadChoices() {
        loading = true;
        String serverId = selectedServer() == null
                ? WildFlyProjectSettings.getInstance(project).getState().selectedServerId
                : selectedServer().id;
        String serviceId = selectedService() == null
                ? WildFlyProjectSettings.getInstance(project).getState().selectedServiceId
                : selectedService().id;

        DefaultComboBoxModel<ServerProfile> servers = new DefaultComboBoxModel<>();
        for (ServerProfile server : WildFlyApplicationSettings.getInstance().servers()) servers.addElement(server);
        serverCombo.setModel(servers);
        selectServer(serverId);

        DefaultComboBoxModel<ServiceProfile> services = new DefaultComboBoxModel<>();
        for (ServiceProfile service : WildFlyProjectSettings.getInstance(project).services()) services.addElement(service);
        serviceCombo.setModel(services);
        selectService(serviceId);
        loading = false;
        refreshStatus();
    }

    private void openManager() {
        ApplicationManager.getApplication().invokeLater(() -> {
            WildFlyManagerDialog dialog = new WildFlyManagerDialog(project);
            dialog.show();
            reloadChoices();
        });
    }

    private void start(boolean debug) {
        ServerProfile server = requireServer();
        if (server == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                WildFlyProcessService.getInstance(project).start(server, debug, this::message);
            } catch (Exception ex) {
                message("ERROR: " + ex.getMessage());
            }
        });
    }

    private void startDebug() {
        ServerProfile server = requireServer();
        if (server == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                WildFlyProcessService process = WildFlyProcessService.getInstance(project);
                if (process.isRunning(server) && !process.isDebugRunning(server)) process.terminateAndWait(server, this::message);
                if (!process.isRunning(server)) process.start(server, true, this::message);
                DebugAttachService.attachWhenAvailable(project, "localhost", server.debugPort, this::message);
            } catch (Exception ex) {
                message("ERROR: " + ex.getMessage());
            }
        });
    }

    private void attach() {
        ServerProfile server = requireServer();
        if (server != null) DebugAttachService.attachWhenAvailable(project, "localhost", server.debugPort, this::message);
    }

    private void stop() {
        ServerProfile server = requireServer();
        if (server != null) WildFlyProcessService.getInstance(project).terminate(server, this::message);
    }

    private void buildAndRedeploy() {
        ServiceProfile service = requireService();
        ServerProfile server = requireServer();
        if (service == null || server == null) return;
        ServiceProfile snapshot = new ServiceProfile(service);
        BuildService.build(project, snapshot,
                () -> deploy(snapshot, server),
                () -> message("Build failed; deploy skipped."),
                this::message);
    }

    private void redeploy() {
        ServiceProfile service = requireService();
        ServerProfile server = requireServer();
        if (service != null && server != null) deploy(new ServiceProfile(service), server);
    }

    private void undeploy() {
        ServiceProfile service = requireService();
        ServerProfile server = requireServer();
        if (service == null || server == null) return;
        String name = service.deploymentName == null || service.deploymentName.isBlank()
                ? defaultDeploymentName(service)
                : service.deploymentName.trim();
        DeploymentScannerService.undeploy(project, server, name, this::message,
                ok -> SwingUtilities.invokeLater(this::refreshStatus));
    }

    private void deploy(ServiceProfile service, ServerProfile server) {
        try {
            Path artifact = ArtifactLocator.resolve(project, service);
            String name = ArtifactLocator.effectiveDeploymentName(service, artifact);
            message("Deploying " + ServicePresentation.displayName(project, service) + " as " + name);
            DeploymentScannerService.deploy(project, server, artifact, name, this::message,
                    ok -> SwingUtilities.invokeLater(this::refreshStatus));
        } catch (Exception ex) {
            message("ERROR: " + ex.getMessage());
        }
    }

    private void refreshStatus() {
        ServerProfile server = selectedServer();
        if (server == null) {
            setStatus(serverState, "No server", false);
        } else {
            WildFlyProcessService process = WildFlyProcessService.getInstance(project);
            if (process.isDebugRunning(server)) setStatus(serverState, "Debug :" + server.debugPort, true);
            else if (process.isRunning(server)) setStatus(serverState, "Running", true);
            else setStatus(serverState, "Stopped / external", false);
        }

        ServiceProfile service = selectedService();
        if (server == null || service == null) setDeploymentStatus("—");
        else {
            try {
                String name = service.deploymentName == null || service.deploymentName.isBlank()
                        ? ArtifactLocator.effectiveDeploymentName(service, ArtifactLocator.resolve(project, service))
                        : service.deploymentName.trim();
                setDeploymentStatus(DeploymentScannerService.status(server, name));
            } catch (Exception ignored) {
                setDeploymentStatus("NOT BUILT");
            }
        }
    }

    private void setDeploymentStatus(String status) {
        deploymentState.setText(status);
        deploymentState.setToolTipText(status);
        deploymentState.setForeground(switch (status) {
            case "DEPLOYED" -> JBUI.CurrentTheme.ProgressBar.PASSED;
            case "FAILED" -> JBUI.CurrentTheme.ProgressBar.FAILED;
            case "DEPLOYING", "UNDEPLOYING", "PENDING" -> JBUI.CurrentTheme.ProgressBar.WARNING;
            default -> UIManager.getColor("Label.foreground");
        });
    }

    private static void setStatus(JLabel label, String text, boolean positive) {
        label.setText(text);
        label.setForeground(positive ? JBUI.CurrentTheme.ProgressBar.PASSED : UIManager.getColor("Label.foreground"));
    }

    private ServerProfile selectedServer() {
        return (ServerProfile) serverCombo.getSelectedItem();
    }

    private ServiceProfile selectedService() {
        return (ServiceProfile) serviceCombo.getSelectedItem();
    }

    private ServerProfile requireServer() {
        ServerProfile server = selectedServer();
        if (server == null) message("Open Configure… and add/select a WildFly server first.");
        return server;
    }

    private ServiceProfile requireService() {
        ServiceProfile service = selectedService();
        if (service == null) message("Select a service, or use Configure… to discover projects.");
        return service;
    }

    private void selectServer(String id) {
        if (id == null || id.isBlank()) return;
        for (int i = 0; i < serverCombo.getItemCount(); i++) {
            if (id.equals(serverCombo.getItemAt(i).id)) {
                serverCombo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void selectService(String id) {
        if (id == null || id.isBlank()) {
            serviceCombo.setSelectedItem(null);
            return;
        }
        for (int i = 0; i < serviceCombo.getItemCount(); i++) {
            if (id.equals(serviceCombo.getItemAt(i).id)) {
                serviceCombo.setSelectedIndex(i);
                return;
            }
        }
        serviceCombo.setSelectedItem(null);
    }

    private void editStandaloneConfig() {
        ServerProfile profile = requireServer();
        if (profile != null) openInEditor(WildFlyPaths.configurationFile(profile));
    }

    private void openLog() {
        ServerProfile profile = requireServer();
        if (profile == null) return;
        Path log = WildFlyPaths.logFile(profile);
        if (!Files.isRegularFile(log)) { message("server.log not found yet: " + log); return; }
        openInEditor(log);
    }

    private void openWildFlyHome() {
        ServerProfile profile = requireServer();
        if (profile != null) openFolder(WildFlyPaths.home(profile));
    }

    private void openDeploymentsFolder() {
        ServerProfile profile = requireServer();
        if (profile != null) openFolder(WildFlyPaths.deploymentsDir(profile));
    }

    private void openInEditor(Path path) {
        ApplicationManager.getApplication().invokeLater(() -> {
            VirtualFile file = LocalFileSystem.getInstance().refreshAndFindFileByNioFile(path);
            if (file == null) { message("File not found: " + path); return; }
            FileEditorManager.getInstance(project).openFile(file, true);
        });
    }

    private void openFolder(Path path) {
        try {
            if (!Files.isDirectory(path)) { message("Folder not found: " + path); return; }
            if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(path.toFile());
            else message("Desktop folder opening is not supported on this system: " + path);
        } catch (Exception e) {
            message("ERROR opening folder: " + e.getMessage());
        }
    }

    private static String defaultDeploymentName(ServiceProfile service) {
        String ext = service.packaging == null ? "war" : service.packaging.trim().toLowerCase();
        if (!(ext.equals("war") || ext.equals("ear") || ext.equals("jar"))) ext = "war";
        String base = service.name == null || service.name.isBlank() ? "service" : service.name.replaceAll("[^A-Za-z0-9._-]", "-");
        return base + "." + ext;
    }

    private void message(String text) {
        if (text == null || text.isBlank()) return;
        SwingUtilities.invokeLater(() -> {
            activity.append("[" + LocalTime.now().format(TIME) + "] " + text + System.lineSeparator());
            if (activity.getLineCount() > 120) activity.setText(activity.getText().substring(Math.max(0, activity.getText().length() / 2)));
            activity.setCaretPosition(activity.getDocument().getLength());
            refreshStatus();
        });
    }

    @Override
    public void removeNotify() {
        refreshTimer.stop();
        super.removeNotify();
    }
}
