package io.github.wildflycommunityrunner.services;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.util.WildFlyPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.function.Consumer;

public final class DeploymentScannerService {
    private static final List<String> MARKERS = List.of(
            ".dodeploy", ".isdeploying", ".deployed", ".failed", ".isundeploying", ".undeployed", ".pending", ".skipdeploy"
    );

    private DeploymentScannerService() {}

    public static void deploy(Project project,
                              ServerProfile profile,
                              Path artifact,
                              String deploymentName,
                              Consumer<String> output,
                              Consumer<Boolean> completion) {
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            boolean success = false;
            try {
                Path deployments = WildFlyPaths.deploymentsDir(profile);
                Files.createDirectories(deployments);
                String name = deploymentName == null || deploymentName.isBlank()
                        ? artifact.getFileName().toString()
                        : deploymentName.trim();
                Path target = deployments.resolve(name);
                Path deployed = deployments.resolve(name + ".deployed");
                long previousDeployedStamp = lastModified(deployed);

                out(output, "Hot redeploy: " + artifact + " -> " + target);
                Files.deleteIfExists(deployments.resolve(name + ".failed"));
                Files.deleteIfExists(deployments.resolve(name + ".undeployed"));
                replaceArtifactSafely(artifact, target);
                Files.writeString(deployments.resolve(name + ".dodeploy"), "", StandardCharsets.UTF_8);
                success = waitForDeployment(project, deployments, name, previousDeployedStamp, output);
            } catch (Exception e) {
                out(output, "ERROR: " + e.getMessage());
            } finally {
                if (completion != null) completion.accept(success);
            }
        });
    }

    public static void undeploy(Project project,
                                ServerProfile profile,
                                String deploymentName,
                                Consumer<String> output,
                                Consumer<Boolean> completion) {
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            boolean success = false;
            try {
                Path deployments = WildFlyPaths.deploymentsDir(profile);
                Path deployed = deployments.resolve(deploymentName + ".deployed");
                Path undeployed = deployments.resolve(deploymentName + ".undeployed");
                if (!Files.exists(deployed)) {
                    out(output, deploymentName + " is not marked as deployed.");
                    success = Files.exists(undeployed);
                } else {
                    out(output, "Undeploying " + deploymentName);
                    Files.deleteIfExists(undeployed);
                    // WildFly's documented deployment-scanner command for undeploy is deleting .deployed.
                    Files.deleteIfExists(deployed);

                    Instant deadline = Instant.now().plus(Duration.ofSeconds(60));
                    while (Instant.now().isBefore(deadline) && !project.isDisposed()) {
                        if (Files.exists(undeployed)) {
                            out(output, "Undeployed " + deploymentName);
                            success = true;
                            break;
                        }
                        Thread.sleep(300);
                    }
                    if (!success) out(output, "Undeploy requested; no .undeployed marker was observed within 60 seconds.");
                }
            } catch (Exception e) {
                out(output, "ERROR: " + e.getMessage());
            } finally {
                if (completion != null) completion.accept(success);
            }
        });
    }

    public static String status(ServerProfile profile, String deploymentName) {
        if (profile == null || deploymentName == null || deploymentName.isBlank()) return "—";
        Path deployments;
        try {
            deployments = WildFlyPaths.deploymentsDir(profile);
        } catch (Exception e) {
            return "—";
        }
        if (Files.exists(deployments.resolve(deploymentName + ".failed"))) return "FAILED";
        if (Files.exists(deployments.resolve(deploymentName + ".isdeploying"))) return "DEPLOYING";
        if (Files.exists(deployments.resolve(deploymentName + ".isundeploying"))) return "UNDEPLOYING";
        if (Files.exists(deployments.resolve(deploymentName + ".pending"))) return "PENDING";
        if (Files.exists(deployments.resolve(deploymentName + ".deployed"))) return "DEPLOYED";
        if (Files.exists(deployments.resolve(deploymentName + ".undeployed"))) return "UNDEPLOYED";
        return Files.exists(deployments.resolve(deploymentName)) ? "PRESENT" : "NOT DEPLOYED";
    }

    public static void cleanupDeployment(ServerProfile profile, String deploymentName) throws IOException {
        Path deployments = WildFlyPaths.deploymentsDir(profile);
        Files.deleteIfExists(deployments.resolve(deploymentName));
        for (String marker : MARKERS) Files.deleteIfExists(deployments.resolve(deploymentName + marker));
        Files.deleteIfExists(deployments.resolve(deploymentName + ".undeploy"));
    }

    private static void replaceArtifactSafely(Path source, Path target) throws IOException {
        Path temp = target.resolveSibling(target.getFileName() + ".uploading");
        Files.deleteIfExists(temp);
        try {
            Files.copy(source, temp, StandardCopyOption.REPLACE_EXISTING);
            try {
                Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }

    private static boolean waitForDeployment(Project project, Path deployments, String name, long previousDeployedStamp, Consumer<String> output) throws Exception {
        Path deployed = deployments.resolve(name + ".deployed");
        Path failed = deployments.resolve(name + ".failed");
        Path deploying = deployments.resolve(name + ".isdeploying");
        Instant deadline = Instant.now().plus(Duration.ofSeconds(60));
        boolean sawDeploying = false;

        while (Instant.now().isBefore(deadline) && !project.isDisposed()) {
            if (Files.exists(deploying)) sawDeploying = true;
            if (Files.exists(failed)) {
                String details = "";
                try { details = Files.readString(failed); } catch (IOException ignored) {}
                out(output, "DEPLOYMENT FAILED: " + name + (details.isBlank() ? "" : "\n" + details));
                return false;
            }
            if (Files.exists(deployed)) {
                long stamp = lastModified(deployed);
                if (previousDeployedStamp == 0L || stamp > previousDeployedStamp || (sawDeploying && !Files.exists(deploying))) {
                    out(output, "Deployment successful: " + name);
                    return true;
                }
            }
            Thread.sleep(300);
        }
        out(output, "Deployment requested; no fresh deployment confirmation was observed within 60 seconds.");
        return false;
    }

    private static long lastModified(Path path) {
        try { return Files.exists(path) ? Files.getLastModifiedTime(path).toMillis() : 0L; }
        catch (IOException e) { return 0L; }
    }

    private static void out(Consumer<String> output, String message) {
        output.accept(message);
    }
}
