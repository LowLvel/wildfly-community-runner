package io.github.wildflycommunityrunner.services;

import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.process.KillableProcessHandler;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.execution.process.ProcessOutputType;
import com.intellij.execution.process.ProcessListener;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Key;
import com.intellij.util.execution.ParametersListUtil;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.util.WildFlyPaths;
import org.jetbrains.annotations.NotNull;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

@Service(Service.Level.PROJECT)
public final class WildFlyProcessService {
    private final Map<String, KillableProcessHandler> handlers = new ConcurrentHashMap<>();
    private final Map<String, Boolean> debugModes = new ConcurrentHashMap<>();

    public static WildFlyProcessService getInstance(Project project) {
        return project.getService(WildFlyProcessService.class);
    }

    public synchronized boolean isRunning(ServerProfile profile) {
        KillableProcessHandler handler = handlers.get(profile.id);
        return handler != null && !handler.isProcessTerminated() && !handler.isProcessTerminating();
    }

    public synchronized boolean isDebugRunning(ServerProfile profile) {
        return isRunning(profile) && Boolean.TRUE.equals(debugModes.get(profile.id));
    }

    public synchronized void start(ServerProfile profile, boolean debug, Consumer<String> output) throws Exception {
        if (isRunning(profile)) {
            output.accept("Server is already running from this plugin session: " + profile.name);
            return;
        }

        String validationError = WildFlyPaths.validate(profile);
        if (validationError != null) throw new IllegalArgumentException(validationError);

        Path script = WildFlyPaths.startupScript(profile);
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        List<String> serverArgs = new ArrayList<>();
        serverArgs.add("-c");
        serverArgs.add(profile.configuration);
        if (debug) {
            serverArgs.add("--debug");
            serverArgs.add(Integer.toString(profile.debugPort));
        }
        if (profile.startupArguments != null && !profile.startupArguments.isBlank()) {
            serverArgs.addAll(ParametersListUtil.parse(profile.startupArguments));
        }

        List<String> command = new ArrayList<>();
        if (windows) {
            command.add("cmd.exe");
            command.add("/c");
        }
        command.add(script.toString());
        command.addAll(serverArgs);
        GeneralCommandLine commandLine = new GeneralCommandLine(command)
                .withWorkingDirectory(script.getParent())
                .withCharset(StandardCharsets.UTF_8);
        if (profile.javaHome != null && !profile.javaHome.isBlank()) {
            commandLine.withEnvironment("JAVA_HOME", profile.javaHome.trim());
        }
        if (profile.jvmOptions != null && !profile.jvmOptions.isBlank()) {
            String inherited = System.getenv("JAVA_OPTS");
            String combined = ((inherited == null ? "" : inherited.trim()) + " " + profile.jvmOptions.trim()).trim();
            commandLine.withEnvironment("JAVA_OPTS", combined);
        }

        output.accept("Starting " + profile.name + (debug ? " in DEBUG mode on port " + profile.debugPort : "")
                + " using " + profile.configuration);
        KillableProcessHandler handler = new KillableProcessHandler(commandLine);
        handler.setShouldKillProcessSoftly(false);
        handlers.put(profile.id, handler);
        debugModes.put(profile.id, debug);
        handler.addProcessListener(new ProcessListener() {
            @Override
            @SuppressWarnings("rawtypes")
            public void onTextAvailable(@NotNull ProcessEvent event, @NotNull Key outputType) {
                String text = event.getText().stripTrailing();
                if (text.isBlank()) return;
                output.accept(ProcessOutputType.isStderr(outputType) ? "[stderr] " + text : text);
            }

            @Override
            public void processTerminated(@NotNull ProcessEvent event) {
                handlers.remove(profile.id);
                debugModes.remove(profile.id);
                output.accept(profile.name + " terminated with exit code " + event.getExitCode());
            }
        });
        handler.startNotify();
    }

    public void terminateAndWait(ServerProfile profile, Consumer<String> output) throws InterruptedException {
        KillableProcessHandler handler;
        synchronized (this) {
            handler = handlers.get(profile.id);
            if (handler == null || handler.isProcessTerminated()) return;
            output.accept("Restarting " + profile.name + " for debug...");
            handler.killProcess();
        }
        long deadline = System.currentTimeMillis() + 10_000L;
        while (!handler.isProcessTerminated() && System.currentTimeMillis() < deadline) {
            Thread.sleep(100L);
        }
        if (!handler.isProcessTerminated()) {
            throw new IllegalStateException("WildFly did not terminate within 10 seconds.");
        }
    }

    public synchronized void terminate(ServerProfile profile, Consumer<String> output) {
        KillableProcessHandler handler = handlers.get(profile.id);
        if (handler == null || handler.isProcessTerminated()) {
            output.accept("No process for " + profile.name + " was started by this plugin session.");
            return;
        }
        output.accept("Terminating " + profile.name + "...");
        handler.killProcess();
    }
}
