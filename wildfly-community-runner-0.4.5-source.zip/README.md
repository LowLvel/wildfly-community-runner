# WildFly Community Runner

WildFly integration for IntelliJ IDEA Community/free mode, focused on fast local multi-service development.

## UI in 0.4.5

The WildFly tool window is the full workspace and has exactly two tabs:

- **Services** — server controls, the service table, selection/inclusion controls, and selected-service actions.
- **Logs** — Maven/Gradle build output, deployment activity, server messages, and a shortcut to `server.log`.

The Services tab now follows IntelliJ collection-editor conventions more closely:

- **Discover, Add, Edit and Remove** are compact icon actions attached directly to the service table via IntelliJ's own toolbar component.
- The table supports native **Shift-click range selection** and **Ctrl/Cmd-click discontiguous selection**.
- Build, redeploy and undeploy commands operate on the current row selection sequentially. The persistent **Include** checkboxes remain a separate concept for recurring bulk operations.
- The footer shows a stable summary such as `3 selected · 5 included`; it no longer competes horizontally with the service list buttons.
- Double-click or Enter opens Service Details only when exactly one service is selected. Right-click keeps an existing multi-selection and exposes actions for the selected set.
- Server controls and service controls are visually separate and use standard IntelliJ icons instead of a custom color palette.
- Action groups reflow into fewer columns when the tool window becomes narrow, instead of allowing buttons to disappear off-screen.

The 0.4.5 threading fix also moves document saving and Maven run-configuration creation into `Application.invokeLater()`. This is required by IntelliJ Platform 2025.1's write-intent threading changes and fixes the `Access is allowed from write thread only` error previously triggered by Build and Redeploy.

## Highlights

### WildFly server profiles

- Save multiple WildFly installations/versions.
- Select `WILDFLY_HOME` and `standalone*.xml` per profile.
- Optional custom `JAVA_HOME`, startup arguments and WildFly JVM options.
- Configurable debugger port (default `8787`).
- Start Server, Debug Server, Attach Debugger and Stop Server directly from the tool window.
- Common server file/folder shortcuts under **More ▾**.
- Common JVM-option shortcuts with path pickers, including `-Doracle.net.tns_admin=...`, trustStore, keyStore and temp directory. Custom JVM options remain fully editable.

### Multi-service workspace

Each deployable service has its own persistent profile:

- Maven **or Gradle** build system.
- Project selector plus manual build-file picker (`pom.xml`, `build.gradle`, `build.gradle.kts`).
- Independent tasks/goals, build arguments and build JVM options.
- Artifact type (`auto`, WAR, EAR, JAR), optional artifact override and stable WildFly deployment name.
- Build, **Build and Redeploy**, Redeploy and Undeploy operate on the current service selection; multiple selected services are processed sequentially.
- Auto-detection searches only that service's output: `target/` for Maven or `build/libs/` for Gradle.
- Open the selected module or reveal its built artifact from **More ▾**.

### Nested projects and hierarchy

**Discover Projects** merges projects IntelliJ already knows about with a bounded recursive filesystem scan under the workspace root. This means nested Maven/Gradle services can be discovered even before IntelliJ imports them as modules.

Output/vendor directories such as `.git`, `.idea`, `.gradle`, `target`, `build`, `out`, `node_modules`, and similar folders are skipped.

The service list preserves hierarchy in its display. For example:

```text
backend › billing › api  —  billing-api
backend › orders › api   —  orders-api
frontend › gateway
```

The build-file path remains the canonical identity, so duplicate names in different subfolders remain distinct.

### Included services and bulk actions

The first service-table column is **Include**. It controls only bulk operations; selecting a row is independent from whether it is included.

**Include ▾** provides:

- Include all
- Include none
- Include only selected
- Invert inclusion

The service footer shows both the current selection count and the persistent included-service count. The current row selection can be cleared with **Esc** or by clicking below the table rows, and an empty selection remains empty across refreshes.

**Bulk Actions ▾** provides:

- Build and redeploy included
- Redeploy included
- Undeploy included
- Undeploy all configured services

Newly discovered services are excluded from bulk operations by default to avoid accidental mass redeploys.

### Deployment status

Statuses are visible at a glance and use IntelliJ theme-aware colors:

- **Deployed** — success color
- **Deploying / Undeploying / Pending** — warning color
- **Failed** — failure color
- **Undeployed / Not deployed / Present** — normal IDE foreground

Periodic status refreshes repaint status only; they do not rebuild the table model or clear the selected service.

## Build engines

### Maven

Maven builds use IntelliJ's bundled Maven runner, so the configured Maven installation/settings in IntelliJ are reused.

### Gradle

Gradle builds prefer the selected project's `gradlew` / `gradlew.bat`, discovered by walking upward from the selected module. If no wrapper exists, the plugin falls back to a system `gradle`/`gradle.bat` command.

Gradle output is streamed into the **Logs** tab. Build JVM options are passed to the Gradle build JVM via `-Dorg.gradle.jvmargs=...`.

## Deployment / hot redeploy

Deployments use WildFly's built-in standalone deployment scanner:

1. Build only the selected service.
2. Locate its WAR/EAR/JAR.
3. Copy to a temporary file under `standalone/deployments`.
4. Atomically replace the target when supported.
5. Create `.dodeploy` and watch WildFly's marker files for success/failure.

Other services running in the same WildFly instance are left untouched.

## Debugging

**Debug Server** starts the selected WildFly profile with:

```text
--debug <configured-port>
```

and automatically attaches IntelliJ's Java debugger when the port becomes available. **Attach Debugger** can attach to an already-running WildFly process listening on that port.

Hot redeploy does not require detaching the debugger; the same WildFly JVM remains alive while an individual service is redeployed.

## Threading fixes

The manager preserves service selection during deployment-status refreshes. Maven run-configuration creation is dispatched through IntelliJ's application queue, project-model discovery runs in a read action, and Gradle/process/file work is kept off the UI thread where appropriate. This avoids the selection reset and IDEA 2025.1 write-thread assertion encountered in earlier versions.

## Build the plugin

Requirements:

- JDK 21
- Gradle 9+

```bash
gradle verifyPluginProjectConfiguration
gradle buildPlugin
```

The installable plugin ZIP is generated under:

```text
build/distributions/
```

A GitHub Actions workflow is included and builds/uploads the installable ZIP automatically on pushes to `main`.

## Install

1. Build the plugin (or download the GitHub Actions artifact).
2. IntelliJ IDEA → **Settings → Plugins → gear → Install Plugin from Disk...**
3. Choose the ZIP from `build/distributions/`.
4. Restart IntelliJ.
5. Open **View → Tool Windows → WildFly**.

## Scope

Current scope is local WildFly **standalone mode**. Domain mode and remote deployment-management APIs are intentionally out of scope for this lightweight Community-focused plugin.

## License

Apache-2.0
