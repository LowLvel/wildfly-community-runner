# WildFly Community Runner

A small IntelliJ IDEA plugin that brings the local WildFly workflow into IntelliJ IDEA Community/free mode.

## What it does

- Save multiple local WildFly installations (different versions are fine).
- Choose the WildFly Home and configuration (`standalone.xml`, `standalone-full.xml`, ...).
- Start WildFly from the IDE and stream its process output into the WildFly tool window.
- Terminate a WildFly process started by the plugin.
- Build Maven projects using IntelliJ's bundled Maven integration.
- Deploy and redeploy a WAR using WildFly's native `standalone/deployments` deployment scanner.
- Undeploy the current WAR.
- Open `standalone/log/server.log` directly in IntelliJ.
- Auto-detect the newest `target/*.war` when the WAR field is blank.

No `jboss-cli`, WildFly Maven plugin, custom management client, or external IntelliJ plugin is required. The plugin only depends on IntelliJ's bundled Maven integration and the WildFly installation you already have.

## Current scope

This is intentionally an MVP for **local standalone WildFly development**. It does not yet support domain mode, remote WildFly hosts, graceful management-API shutdown, exploded deployments, or a custom Run Configuration type.

## Build

Requirements:

- JDK 21
- Gradle 9+

```bash
gradle buildPlugin
```

The installable ZIP will be created under `build/distributions/`.

For plugin development:

```bash
gradle runIde
```

## Install

1. Build the plugin ZIP.
2. In IntelliJ IDEA: **Settings > Plugins > gear icon > Install Plugin from Disk...**
3. Select the ZIP from `build/distributions/`.
4. Restart IntelliJ.
5. Open **View > Tool Windows > WildFly**.
6. Click **Add**, select your WildFly Home, and choose the configuration file.
7. Leave `WAR` blank to auto-detect a built WAR under `target/`, or choose it explicitly.
8. Click **Build & Deploy**.

## Multiple WildFly versions

Add one profile per installation, for example:

- `C:\servers\wildfly-26.1.3.Final`
- `C:\servers\wildfly-30.0.1.Final`

The selected profile is stored per project, while the profile list is shared across IntelliJ projects.

## Deployment model

The plugin copies the WAR into:

```text
<WILDFLY_HOME>/standalone/deployments/
```

and creates the `.dodeploy` marker. It observes `.deployed` and `.failed` markers for feedback. This is WildFly's built-in deployment-scanner workflow.

## License

Apache-2.0
