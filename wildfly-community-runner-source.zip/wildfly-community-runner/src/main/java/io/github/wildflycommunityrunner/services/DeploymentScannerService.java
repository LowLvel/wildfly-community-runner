package io.github.wildflycommunityrunner.services;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.util.WildFlyPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.function.Consumer;

public final class DeploymentScannerService {
    private static final List<String> MARKERS = List.of(
            ".dodeploy", ".isdeploying", ".deployed", ".failed", ".isundeploying", ".undeployed", ".pending", ".skipdeploy"
    );

    private DeploymentScannerService() {}

    public static void deploy(Project project, ServerProfile profile, Path war, Consumer<String> output) {
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                Path deployments = WildFlyPaths.deploymentsDir(profile);
                Files.createDirectories(deployments);
                String name = war.getFileName().toString();
                Path target = deployments.resolve(name);

                out(output, "Deploying " + war + " -> " + target);
                Files.copy(war, target, StandardCopyOption.REPLACE_EXISTING);
                Files.deleteIfExists(deployments.resolve(name + ".failed"));
                Files.deleteIfExists(deployments.resolve(name + ".undeployed"));
                Files.writeString(deployments.resolve(name + ".dodeploy"), "", StandardCharsets.UTF_8);
                out(output, "Requested deployment via " + name + ".dodeploy");
                waitForDeployment(project, deployments, name, output);
            } catch (Exception e) {
                out(output, "ERROR: " + e.getMessage());
            }
        });
    }

    public static void redeploy(Project project, ServerProfile profile, Path war, Consumer<String> output) {
        deploy(project, profile, war, output);
    }

    public static void undeploy(Project project, ServerProfile profile, String deploymentName, Consumer<String> output) {
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                Path deployments = WildFlyPaths.deploymentsDir(profile);
                Path deployedMarker = deployments.resolve(deploymentName + ".deployed");
                Path content = deployments.resolve(deploymentName);

                out(output, "Requesting undeploy of " + deploymentName);
                Files.deleteIfExists(deployedMarker);
                Files.deleteIfExists(content);
                Files.deleteIfExists(deployments.resolve(deploymentName + ".dodeploy"));

                Instant deadline = Instant.now().plus(Duration.ofSeconds(60));
                Path undeployed = deployments.resolve(deploymentName + ".undeployed");
                while (Instant.now().isBefore(deadline) && !project.isDisposed()) {
                    if (Files.exists(undeployed) || (!Files.exists(content) && !Files.exists(deployedMarker))) {
                        out(output, "Undeployed " + deploymentName);
                        return;
                    }
                    Thread.sleep(300);
                }
                out(output, "Undeploy requested. No confirmation marker was observed within 60 seconds.");
            } catch (Exception e) {
                out(output, "ERROR: " + e.getMessage());
            }
        });
    }

    public static void cleanupDeployment(ServerProfile profile, String deploymentName) throws IOException {
        Path deployments = WildFlyPaths.deploymentsDir(profile);
        Files.deleteIfExists(deployments.resolve(deploymentName));
        for (String marker : MARKERS) {
            Files.deleteIfExists(deployments.resolve(deploymentName + marker));
        }
    }

    private static void waitForDeployment(Project project, Path deployments, String name, Consumer<String> output) throws Exception {
        Path deployed = deployments.resolve(name + ".deployed");
        Path failed = deployments.resolve(name + ".failed");
        Instant deadline = Instant.now().plus(Duration.ofSeconds(60));

        while (Instant.now().isBefore(deadline) && !project.isDisposed()) {
            if (Files.exists(deployed)) {
                out(output, "Deployment successful: " + name);
                return;
            }
            if (Files.exists(failed)) {
                String details = "";
                try {
                    details = Files.readString(failed);
                } catch (IOException ignored) {}
                out(output, "DEPLOYMENT FAILED: " + name + (details.isBlank() ? "" : "\n" + details));
                return;
            }
            Thread.sleep(300);
        }
        out(output, "Deployment requested. No .deployed/.failed marker was observed within 60 seconds.");
    }

    private static void out(Consumer<String> output, String message) {
        output.accept(message);
    }
}
