package io.github.wildflycommunityrunner.util;

import com.intellij.openapi.project.Project;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Stream;

public final class ArtifactLocator {
    private ArtifactLocator() {}

    public static Path resolve(Project project, String configuredPath) throws IOException {
        Path base = Path.of(project.getBasePath() == null ? "." : project.getBasePath()).toAbsolutePath().normalize();
        if (configuredPath != null && !configuredPath.isBlank()) {
            Path configured = Path.of(configuredPath);
            if (!configured.isAbsolute()) configured = base.resolve(configured);
            configured = configured.normalize();
            if (!Files.isRegularFile(configured)) throw new IOException("WAR not found: " + configured);
            if (!configured.getFileName().toString().toLowerCase().endsWith(".war")) throw new IOException("Artifact is not a .war file: " + configured);
            return configured;
        }

        try (Stream<Path> paths = Files.walk(base, 5)) {
            return paths
                    .filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().toLowerCase().endsWith(".war"))
                    .filter(p -> containsTargetDirectory(base, p))
                    .max(Comparator.comparingLong(ArtifactLocator::lastModified))
                    .orElseThrow(() -> new IOException("No WAR found under a target/ directory. Set Artifact explicitly."));
        }
    }

    private static boolean containsTargetDirectory(Path base, Path p) {
        Path rel;
        try {
            rel = base.relativize(p);
        } catch (IllegalArgumentException e) {
            return false;
        }
        for (Path part : rel) {
            if ("target".equals(part.toString())) return true;
        }
        return false;
    }

    private static long lastModified(Path p) {
        try {
            return Files.getLastModifiedTime(p).toMillis();
        } catch (IOException e) {
            return 0L;
        }
    }
}
