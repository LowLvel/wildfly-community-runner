package io.github.wildflycommunityrunner.settings;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import io.github.wildflycommunityrunner.model.ServerProfile;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

@Service(Service.Level.APP)
@State(name = "WildFlyCommunityRunner", storages = @Storage("wildflyCommunityRunner.xml"))
public final class WildFlyApplicationSettings implements PersistentStateComponent<WildFlyApplicationSettings.StateData> {
    public static final class StateData {
        public List<ServerProfile> servers = new ArrayList<>();
    }

    private StateData state = new StateData();

    public static WildFlyApplicationSettings getInstance() {
        return ApplicationManager.getApplication().getService(WildFlyApplicationSettings.class);
    }

    @Override
    public @NotNull StateData getState() {
        return state;
    }

    @Override
    public void loadState(@NotNull StateData state) {
        this.state = state;
        if (this.state.servers == null) this.state.servers = new ArrayList<>();
    }

    public List<ServerProfile> servers() {
        return state.servers;
    }
}
