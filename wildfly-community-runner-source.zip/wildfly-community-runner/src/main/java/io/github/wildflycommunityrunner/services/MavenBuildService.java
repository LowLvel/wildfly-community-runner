package io.github.wildflycommunityrunner.services;

import com.intellij.openapi.project.Project;
import com.intellij.util.execution.ParametersListUtil;
import org.jetbrains.idea.maven.execution.MavenRunner;
import org.jetbrains.idea.maven.execution.MavenRunnerParameters;

import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public final class MavenBuildService {
    private MavenBuildService() {}

    public static void build(Project project,
                             String workingDirectory,
                             String goalsText,
                             Runnable onSuccess,
                             Consumer<String> output) {
        String basePath = project.getBasePath();
        String workDir = workingDirectory == null || workingDirectory.isBlank() ? basePath : workingDirectory;
        if (workDir == null || workDir.isBlank()) {
            output.accept("ERROR: Project base path is unavailable.");
            return;
        }

        List<String> goals = ParametersListUtil.parse(goalsText == null || goalsText.isBlank() ? "package" : goalsText);
        MavenRunnerParameters parameters = new MavenRunnerParameters(
                true,
                workDir,
                null,
                goals,
                Collections.emptyList()
        );

        output.accept("Running Maven via IntelliJ: " + String.join(" ", goals));
        MavenRunner runner = MavenRunner.getInstance(project);
        runner.run(parameters, runner.getSettings().clone(), () -> {
            output.accept("Maven build completed successfully.");
            if (onSuccess != null) onSuccess.run();
        });
    }
}
