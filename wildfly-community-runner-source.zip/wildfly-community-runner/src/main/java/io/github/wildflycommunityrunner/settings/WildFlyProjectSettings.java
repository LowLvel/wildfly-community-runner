package io.github.wildflycommunityrunner.settings;

import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import com.intellij.openapi.components.StoragePathMacros;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;

@Service(Service.Level.PROJECT)
@State(name = "WildFlyCommunityRunnerProject", storages = @Storage(StoragePathMacros.WORKSPACE_FILE))
public final class WildFlyProjectSettings implements PersistentStateComponent<WildFlyProjectSettings.StateData> {
    public static final class StateData {
        public String selectedServerId = "";
        public String artifactPath = "";
        public String mavenGoals = "clean package -DskipTests";
        public String mavenWorkingDirectory = "";
    }

    private StateData state = new StateData();

    public static WildFlyProjectSettings getInstance(Project project) {
        return project.getService(WildFlyProjectSettings.class);
    }

    @Override
    public @NotNull StateData getState() {
        return state;
    }

    @Override
    public void loadState(@NotNull StateData state) {
        this.state = state;
    }
}
