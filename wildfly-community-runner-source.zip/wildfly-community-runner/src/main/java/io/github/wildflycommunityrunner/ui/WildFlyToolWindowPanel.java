package io.github.wildflycommunityrunner.ui;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.services.DeploymentScannerService;
import io.github.wildflycommunityrunner.services.MavenBuildService;
import io.github.wildflycommunityrunner.services.WildFlyProcessService;
import io.github.wildflycommunityrunner.settings.WildFlyApplicationSettings;
import io.github.wildflycommunityrunner.settings.WildFlyProjectSettings;
import io.github.wildflycommunityrunner.util.ArtifactLocator;
import io.github.wildflycommunityrunner.util.WildFlyPaths;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class WildFlyToolWindowPanel extends JPanel {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final Project project;
    private final JComboBox<ServerProfile> serverCombo = new JComboBox<>();
    private final JTextField artifactField = new JTextField();
    private final JTextField goalsField = new JTextField();
    private final JTextField workingDirField = new JTextField();
    private final JTextArea output = new JTextArea();
    private boolean loading;

    public WildFlyToolWindowPanel(Project project) {
        super(new BorderLayout(8, 8));
        this.project = project;
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        buildUi();
        loadSettings();
    }

    private void buildUi() {
        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        JPanel serverRow = new JPanel(new BorderLayout(6, 0));
        serverRow.add(new JLabel("Server:"), BorderLayout.WEST);
        serverRow.add(serverCombo, BorderLayout.CENTER);
        JPanel serverButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        JButton add = new JButton("Add");
        JButton edit = new JButton("Edit");
        JButton remove = new JButton("Remove");
        serverButtons.add(add);
        serverButtons.add(edit);
        serverButtons.add(remove);
        serverRow.add(serverButtons, BorderLayout.EAST);
        top.add(serverRow);
        top.add(Box.createVerticalStrut(6));

        JPanel artifactRow = new JPanel(new BorderLayout(6, 0));
        artifactRow.add(new JLabel("WAR:"), BorderLayout.WEST);
        artifactField.setToolTipText("Leave blank to auto-detect the newest target/*.war");
        artifactRow.add(artifactField, BorderLayout.CENTER);
        JButton browseArtifact = new JButton("Browse…");
        artifactRow.add(browseArtifact, BorderLayout.EAST);
        top.add(artifactRow);
        top.add(Box.createVerticalStrut(6));

        JPanel mavenRow = new JPanel(new BorderLayout(6, 0));
        mavenRow.add(new JLabel("Maven goals:"), BorderLayout.WEST);
        mavenRow.add(goalsField, BorderLayout.CENTER);
        top.add(mavenRow);
        top.add(Box.createVerticalStrut(6));

        JPanel workingDirRow = new JPanel(new BorderLayout(6, 0));
        workingDirRow.add(new JLabel("Maven dir:"), BorderLayout.WEST);
        workingDirField.setToolTipText("Leave blank to use the project root");
        workingDirRow.add(workingDirField, BorderLayout.CENTER);
        JButton browseDir = new JButton("Browse…");
        workingDirRow.add(browseDir, BorderLayout.EAST);
        top.add(workingDirRow);
        top.add(Box.createVerticalStrut(8));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JButton start = new JButton("Start");
        JButton stop = new JButton("Terminate");
        JButton buildDeploy = new JButton("Build & Deploy");
        JButton redeploy = new JButton("Redeploy");
        JButton undeploy = new JButton("Undeploy");
        JButton log = new JButton("Open server.log");
        actions.add(start);
        actions.add(stop);
        actions.add(buildDeploy);
        actions.add(redeploy);
        actions.add(undeploy);
        actions.add(log);
        top.add(actions);

        add(top, BorderLayout.NORTH);

        output.setEditable(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, output.getFont().getSize()));
        JScrollPane scroll = new JScrollPane(output);
        scroll.setBorder(BorderFactory.createTitledBorder("WildFly output"));
        add(scroll, BorderLayout.CENTER);

        add.addActionListener(e -> addServer());
        edit.addActionListener(e -> editServer());
        remove.addActionListener(e -> removeServer());
        serverCombo.addActionListener(e -> saveSelectedServer());
        browseArtifact.addActionListener(e -> browseFile(artifactField, false));
        browseDir.addActionListener(e -> browseFile(workingDirField, true));
        start.addActionListener(e -> startServer());
        stop.addActionListener(e -> terminateServer());
        buildDeploy.addActionListener(e -> buildAndDeploy());
        redeploy.addActionListener(e -> deployCurrentArtifact());
        undeploy.addActionListener(e -> undeployCurrentArtifact());
        log.addActionListener(e -> openLog());

        DocumentListener saver = new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { saveProjectFields(); }
            @Override public void removeUpdate(DocumentEvent e) { saveProjectFields(); }
            @Override public void changedUpdate(DocumentEvent e) { saveProjectFields(); }
        };
        artifactField.getDocument().addDocumentListener(saver);
        goalsField.getDocument().addDocumentListener(saver);
        workingDirField.getDocument().addDocumentListener(saver);
    }

    private void loadSettings() {
        loading = true;
        refreshServers();
        WildFlyProjectSettings.StateData state = WildFlyProjectSettings.getInstance(project).getState();
        artifactField.setText(state.artifactPath == null ? "" : state.artifactPath);
        goalsField.setText(state.mavenGoals == null || state.mavenGoals.isBlank() ? "clean package -DskipTests" : state.mavenGoals);
        workingDirField.setText(state.mavenWorkingDirectory == null ? "" : state.mavenWorkingDirectory);

        if (state.selectedServerId != null && !state.selectedServerId.isBlank()) {
            for (int i = 0; i < serverCombo.getItemCount(); i++) {
                ServerProfile p = serverCombo.getItemAt(i);
                if (state.selectedServerId.equals(p.id)) {
                    serverCombo.setSelectedIndex(i);
                    break;
                }
            }
        }
        loading = false;
    }

    private void refreshServers() {
        String selectedId = selectedServer() == null ? null : selectedServer().id;
        DefaultComboBoxModel<ServerProfile> model = new DefaultComboBoxModel<>();
        List<ServerProfile> servers = WildFlyApplicationSettings.getInstance().servers();
        for (ServerProfile server : servers) model.addElement(server);
        serverCombo.setModel(model);
        if (selectedId != null) {
            for (int i = 0; i < model.getSize(); i++) {
                if (selectedId.equals(model.getElementAt(i).id)) {
                    serverCombo.setSelectedIndex(i);
                    return;
                }
            }
        }
    }

    private void addServer() {
        ServerProfileDialog dialog = new ServerProfileDialog(project, null);
        if (!dialog.showAndGet()) return;
        ServerProfile profile = dialog.getProfile();
        WildFlyApplicationSettings.getInstance().servers().add(profile);
        refreshServers();
        serverCombo.setSelectedItem(profile);
        append("Added server profile: " + profile);
    }

    private void editServer() {
        ServerProfile current = selectedServer();
        if (current == null) {
            append("Add a WildFly server first.");
            return;
        }
        ServerProfileDialog dialog = new ServerProfileDialog(project, current);
        if (!dialog.showAndGet()) return;
        ServerProfile edited = dialog.getProfile();
        List<ServerProfile> servers = WildFlyApplicationSettings.getInstance().servers();
        for (int i = 0; i < servers.size(); i++) {
            if (servers.get(i).id.equals(current.id)) {
                servers.set(i, edited);
                break;
            }
        }
        refreshServers();
        selectById(edited.id);
        append("Updated server profile: " + edited);
    }

    private void removeServer() {
        ServerProfile current = selectedServer();
        if (current == null) return;
        int answer = JOptionPane.showConfirmDialog(this,
                "Remove server profile '" + current.name + "'?",
                "Remove WildFly Server",
                JOptionPane.YES_NO_OPTION);
        if (answer != JOptionPane.YES_OPTION) return;
        WildFlyApplicationSettings.getInstance().servers().removeIf(p -> p.id.equals(current.id));
        refreshServers();
        saveSelectedServer();
        append("Removed server profile: " + current.name);
    }

    private void startServer() {
        ServerProfile profile = requireServer();
        if (profile == null) return;
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                WildFlyProcessService.getInstance(project).start(profile, this::append);
            } catch (Exception e) {
                append("ERROR: " + e.getMessage());
            }
        });
    }

    private void terminateServer() {
        ServerProfile profile = requireServer();
        if (profile == null) return;
        WildFlyProcessService.getInstance(project).terminate(profile, this::append);
    }

    private void buildAndDeploy() {
        ServerProfile profile = requireServer();
        if (profile == null) return;
        saveProjectFields();
        WildFlyProjectSettings.StateData state = WildFlyProjectSettings.getInstance(project).getState();
        MavenBuildService.build(project, state.mavenWorkingDirectory, state.mavenGoals,
                () -> deployCurrentArtifact(profile), this::append);
    }

    private void deployCurrentArtifact() {
        ServerProfile profile = requireServer();
        if (profile != null) deployCurrentArtifact(profile);
    }

    private void deployCurrentArtifact(ServerProfile profile) {
        try {
            Path war = ArtifactLocator.resolve(project, artifactField.getText().trim());
            append("Using WAR: " + war);
            DeploymentScannerService.deploy(project, profile, war, this::append);
        } catch (Exception e) {
            append("ERROR: " + e.getMessage());
        }
    }

    private void undeployCurrentArtifact() {
        ServerProfile profile = requireServer();
        if (profile == null) return;
        try {
            Path war = ArtifactLocator.resolve(project, artifactField.getText().trim());
            DeploymentScannerService.undeploy(project, profile, war.getFileName().toString(), this::append);
        } catch (Exception e) {
            append("ERROR: " + e.getMessage());
        }
    }

    private void openLog() {
        ServerProfile profile = requireServer();
        if (profile == null) return;
        Path log = WildFlyPaths.logFile(profile);
        if (!Files.isRegularFile(log)) {
            append("server.log not found yet: " + log);
            return;
        }
        VirtualFile file = LocalFileSystem.getInstance().refreshAndFindFileByNioFile(log);
        if (file == null) {
            append("Could not open: " + log);
            return;
        }
        FileEditorManager.getInstance(project).openFile(file, true);
    }

    private ServerProfile requireServer() {
        ServerProfile profile = selectedServer();
        if (profile == null) append("No WildFly server configured. Click Add and select your WildFly Home.");
        return profile;
    }

    private ServerProfile selectedServer() {
        Object value = serverCombo.getSelectedItem();
        return value instanceof ServerProfile p ? p : null;
    }

    private void saveSelectedServer() {
        if (loading) return;
        WildFlyProjectSettings.StateData state = WildFlyProjectSettings.getInstance(project).getState();
        ServerProfile selected = selectedServer();
        state.selectedServerId = selected == null ? "" : selected.id;
    }

    private void saveProjectFields() {
        if (loading) return;
        WildFlyProjectSettings.StateData state = WildFlyProjectSettings.getInstance(project).getState();
        state.artifactPath = artifactField.getText().trim();
        state.mavenGoals = goalsField.getText().trim();
        state.mavenWorkingDirectory = workingDirField.getText().trim();
    }

    private void selectById(String id) {
        for (int i = 0; i < serverCombo.getItemCount(); i++) {
            if (id.equals(serverCombo.getItemAt(i).id)) {
                serverCombo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void browseFile(JTextField target, boolean directory) {
        File initial = target.getText().isBlank()
                ? (project.getBasePath() == null ? null : new File(project.getBasePath()))
                : new File(target.getText());
        JFileChooser chooser = new JFileChooser(initial);
        chooser.setFileSelectionMode(directory ? JFileChooser.DIRECTORIES_ONLY : JFileChooser.FILES_ONLY);
        if (!directory) chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("WAR files", "war"));
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            target.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void append(String text) {
        if (text == null || text.isBlank()) return;
        SwingUtilities.invokeLater(() -> {
            output.append("[" + LocalTime.now().format(TIME) + "] " + text + System.lineSeparator());
            output.setCaretPosition(output.getDocument().getLength());
        });
    }
}
