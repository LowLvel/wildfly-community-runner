package io.github.wildflycommunityrunner.services;

import com.intellij.execution.configurations.GeneralCommandLine;
import com.intellij.execution.process.KillableProcessHandler;
import com.intellij.execution.process.ProcessAdapter;
import com.intellij.execution.process.ProcessEvent;
import com.intellij.execution.process.ProcessOutputType;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Key;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.util.WildFlyPaths;
import org.jetbrains.annotations.NotNull;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

@Service(Service.Level.PROJECT)
public final class WildFlyProcessService {
    private final Map<String, KillableProcessHandler> handlers = new ConcurrentHashMap<>();

    public static WildFlyProcessService getInstance(Project project) {
        return project.getService(WildFlyProcessService.class);
    }

    public synchronized boolean isRunning(ServerProfile profile) {
        KillableProcessHandler handler = handlers.get(profile.id);
        return handler != null && !handler.isProcessTerminated() && !handler.isProcessTerminating();
    }

    public synchronized void start(ServerProfile profile, Consumer<String> output) throws Exception {
        if (isRunning(profile)) {
            output.accept("Server is already running from this plugin session: " + profile.name);
            return;
        }

        String validationError = WildFlyPaths.validate(profile);
        if (validationError != null) throw new IllegalArgumentException(validationError);

        Path script = WildFlyPaths.startupScript(profile);
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");

        GeneralCommandLine commandLine;
        if (windows) {
            commandLine = new GeneralCommandLine("cmd.exe", "/c", script.toString(), "-c", profile.configuration);
        } else {
            commandLine = new GeneralCommandLine(script.toString(), "-c", profile.configuration);
        }
        commandLine.setWorkDirectory(script.getParent().toFile());
        commandLine.setCharset(StandardCharsets.UTF_8);
        if (profile.javaHome != null && !profile.javaHome.isBlank()) {
            commandLine.withEnvironment("JAVA_HOME", profile.javaHome);
        }

        output.accept("Starting " + profile.name + " with " + script + " -c " + profile.configuration);
        KillableProcessHandler handler = new KillableProcessHandler(commandLine);
        handler.setShouldKillProcessSoftly(false);
        handlers.put(profile.id, handler);
        handler.addProcessListener(new ProcessAdapter() {
            @Override
            public void onTextAvailable(@NotNull ProcessEvent event, @NotNull Key outputType) {
                String text = event.getText();
                if (ProcessOutputType.isStderr(outputType)) {
                    output.accept("[stderr] " + text.stripTrailing());
                } else {
                    output.accept(text.stripTrailing());
                }
            }

            @Override
            public void processTerminated(@NotNull ProcessEvent event) {
                handlers.remove(profile.id);
                output.accept(profile.name + " terminated with exit code " + event.getExitCode());
            }
        });
        handler.startNotify();
    }

    public synchronized void terminate(ServerProfile profile, Consumer<String> output) {
        KillableProcessHandler handler = handlers.get(profile.id);
        if (handler == null || handler.isProcessTerminated()) {
            output.accept("No process for " + profile.name + " was started by this plugin session.");
            return;
        }
        output.accept("Terminating " + profile.name + "...");
        handler.killProcess();
    }
}
