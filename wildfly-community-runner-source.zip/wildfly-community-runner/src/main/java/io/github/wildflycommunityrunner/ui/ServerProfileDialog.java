package io.github.wildflycommunityrunner.ui;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.DialogWrapper;
import com.intellij.openapi.ui.ValidationInfo;
import io.github.wildflycommunityrunner.model.ServerProfile;
import io.github.wildflycommunityrunner.util.WildFlyPaths;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public final class ServerProfileDialog extends DialogWrapper {
    private final JTextField nameField = new JTextField(30);
    private final JTextField homeField = new JTextField(30);
    private final JTextField configField = new JTextField(30);
    private final JTextField javaHomeField = new JTextField(30);
    private final ServerProfile profile;

    public ServerProfileDialog(Project project, @Nullable ServerProfile existing) {
        super(project, true);
        this.profile = existing == null ? new ServerProfile() : new ServerProfile(existing);
        setTitle(existing == null ? "Add WildFly Server" : "Edit WildFly Server");
        nameField.setText(profile.name);
        homeField.setText(profile.home);
        configField.setText(profile.configuration);
        javaHomeField.setText(profile.javaHome);
        init();
    }

    public ServerProfile getProfile() {
        applyFields();
        return profile;
    }

    @Override
    protected @Nullable JComponent createCenterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 0;

        addRow(panel, c, "Name", nameField, null);
        addRow(panel, c, "WildFly Home", homeField, browseButton(homeField, true));
        addRow(panel, c, "Configuration", configField, null);
        addRow(panel, c, "JAVA_HOME (optional)", javaHomeField, browseButton(javaHomeField, true));

        JLabel hint = new JLabel("Example configuration: standalone.xml or standalone-full.xml");
        c.gridx = 1;
        c.gridy++;
        c.gridwidth = 2;
        c.weightx = 1;
        panel.add(hint, c);
        return panel;
    }

    private static void addRow(JPanel panel, GridBagConstraints c, String label, JComponent field, @Nullable JComponent extra) {
        c.gridwidth = 1;
        c.gridx = 0;
        c.weightx = 0;
        panel.add(new JLabel(label + ":"), c);
        c.gridx = 1;
        c.weightx = 1;
        panel.add(field, c);
        if (extra != null) {
            c.gridx = 2;
            c.weightx = 0;
            panel.add(extra, c);
        }
        c.gridy++;
    }

    private JButton browseButton(JTextField field, boolean directoriesOnly) {
        JButton button = new JButton("Browse…");
        button.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(field.getText().isBlank() ? null : new File(field.getText()));
            chooser.setFileSelectionMode(directoriesOnly ? JFileChooser.DIRECTORIES_ONLY : JFileChooser.FILES_ONLY);
            if (chooser.showOpenDialog(getContentPane()) == JFileChooser.APPROVE_OPTION) {
                field.setText(chooser.getSelectedFile().getAbsolutePath());
            }
        });
        return button;
    }

    private void applyFields() {
        profile.name = nameField.getText().trim();
        profile.home = homeField.getText().trim();
        profile.configuration = configField.getText().trim();
        profile.javaHome = javaHomeField.getText().trim();
    }

    @Override
    protected @Nullable ValidationInfo doValidate() {
        applyFields();
        String error = WildFlyPaths.validate(profile);
        return error == null ? null : new ValidationInfo(error);
    }
}
